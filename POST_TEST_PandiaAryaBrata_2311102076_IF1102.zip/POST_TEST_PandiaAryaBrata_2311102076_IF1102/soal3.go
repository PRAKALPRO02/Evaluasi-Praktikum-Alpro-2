package main

import "fmt"

func main() {
	var angka []int
	var n int

	for {
		fmt.Scan(&n)
		if n < 0 {
			break
		}
		angka = append(angka, n)
	}
	fmt.Println("Jadi total kelipatan 4 adalah :", kel4(angka))
}

func kel4(angka []int) int {
	if angka[0] < 0 || len(angka) == 0 {
		return 0
	} else if angka[0]%4 == 0 {
		return angka[0] + kel4(angka[1:])
	}
	return kel4(angka[1:])
}

package main

import "fmt"

func main() {
	var grup, hasil, pengunjung, sisa int

	const hargaBiasa = 10000
	const hargaPerMenu = 2500
	const hargaMaks = 50000

	fmt.Print("Masukan jumlah rombongan : ")
	fmt.Scan(&grup)

	for i := 1; i <= grup; i++ {
		fmt.Printf("Masukan jumlah menu, jumlah orang, dan statu sisa makanan (0 untuk tidak, 1 untuk iya)", i)
		fmt.Scan(&hasil, &pengunjung, &sisa)
		totalHarga := hargaBiasa

		if hasil > 3 {
			totalHarga += (hasil - 3) *
				hargaPerMenu
		}
		totalHarga *= pengunjung
	}

}

package main

import "fmt"

func main() {
	var a, b2311102076 int
	fmt.Print("Masukan nilai : ")
	fmt.Scan(&a, &b2311102076)
	if a%2 == 0 {
		a++
	} else if b2311102076%2 == 0 {
		b2311102076--
	}
	hasil := (b2311102076-a)/2 + 1
	fmt.Println("Banyaknya ganjil : ", hasil)
}

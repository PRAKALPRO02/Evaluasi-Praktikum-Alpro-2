package main

import (
	"fmt"
	"sort"
)

type Partai struct {
	Nama int
	suara          int
}

func main() {
	const MAX = 1000000
	var suara [MAX + 1]int
	var input int

	fmt.Println("Perhitungan Suara Partai")
	fmt.Println("Masukkan nomor partai (1 - 1000000), akhiri dengan -1:")

	// data suara
	for {
		fmt.Scan(&input)
		if input == -1 {
			break
		}
		if input < 1 || input > MAX {
			fmt.Println("Nomor partai tidak valid. mohon masukkan nomor partai antara 1 dan 1000000.")
			continue
		}
		suara[input]++
	}

	// hasil_2311102181 suara
	var hasil_2311102181 []Partai
	for i := 1; i <= MAX; i++ {
		if suara[i] > 0 {
			hasil_2311102181 = append(hasil_2311102181, Partai{Nama: i, suara: suara[i]})
		}
	}

	sort.Slice(hasil_2311102181, func(i, j int) bool {
		if hasil_2311102181[i].suara == hasil_2311102181[j].suara {
			return hasil_2311102181[i].Nama < hasil_2311102181[j].Nama
		}
		return hasil_2311102181[i].suara > hasil_2311102181[j].suara
	})

	// hasil_2311102181 akhir
	fmt.Println("\nhasil_2311102181 Perhitungan Suara:")
	if len(hasil_2311102181) == 0 {
		fmt.Println("Tidak ada suara yang dihitung.")
	} else {
		for i, p := range hasil_2311102181 {
			fmt.Printf("%d. Partai %d: %d suara\n", i+1, p.Nama, p.suara)
		}
	}

	fmt.Println("\ndone kakakk :)")
}

package main

import (
	"fmt"
	"strings"
)

const nProv = 10

type (
	Namaprov [nProv]string
	PopProv            [nProv]int
	TumbuhProv         [nProv]float64
)

func InputData(nama *Namaprov, pop *PopProv, tumbuh *TumbuhProv) {
	for i := 0; i < nProv; i++ {
		fmt.Printf("Provinsi ke-%d:\n", i+1)
		fmt.Print("Nama Provinsi : ")
		fmt.Scanln(&nama[i])
		fmt.Print("Populasi: ")
		fmt.Scanln(&pop[i])
		fmt.Print("Pertumbuhan: ")
		fmt.Scanln(&tumbuh[i])
	}
}

func ProvinsiTercepat_2311102181(tumbuh TumbuhProv) int {
	indeks, maks := 0, tumbuh[0]
	for i := 1; i < nProv; i++ {
		if tumbuh[i] > maks {
			maks, indeks = tumbuh[i], i
		}
	}
	return indeks
}

func IndeksProvinsi(nama Namaprov, target string) int {
	for i := 0; i < nProv; i++ {
		if strings.EqualFold(nama[i], target) {
			return i
		}
	}
	return -1
}

func Prediksi(nama Namaprov, pop PopProv, tumbuh TumbuhProv) {
	fmt.Println("Prediksi provinsi dengan pertumbuhan > 2%:")
	for i := 0; i < nProv; i++ {
		if tumbuh[i] > 0.02 {
			fmt.Printf("%s: Populasi tahun depan = %.0f\n", nama[i], float64(pop[i])*(1+tumbuh[i]))
		}
	}
}

func main() {
	var nama Namaprov
	var pop PopProv
	var tumbuh TumbuhProv

	InputData(&nama, &pop, &tumbuh)

	fmt.Printf("Provinsi dengan pertumbuhan tercepat: %s\n", nama[ProvinsiTercepat_2311102181(tumbuh)])

	fmt.Print("Masukkan nama provinsi yang ingin dicari: ")
	var cari string
	fmt.Scanln(&cari)

	if indeks := IndeksProvinsi(nama, cari); indeks != -1 {
		fmt.Printf("Provinsi %s ditemukan pada indeks %d\n", cari, indeks)
	} else {
		fmt.Printf("Provinsi %s tidak ditemukan\n", cari)
	}

	Prediksi(nama,pop,tumbuh)
}

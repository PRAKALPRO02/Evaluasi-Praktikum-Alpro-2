package main

import (
	"fmt"
)

type Pemain struct {
	Nama string
	Gol            int
	Assist         int
}

func InputData(n int) []Pemain {
	pemain := make([]Pemain, n)
	for i := 0; i < n; i++ {
		fmt.Printf("Masukkan data pemain ke-%d (Nama, Gol, Assist):\n", i+1)
		var NamaDepan, NamaBelakang string
		fmt.Scan(&NamaDepan, &NamaBelakang)
		pemain[i].Nama = NamaDepan + " " + NamaBelakang
		fmt.Scan(&pemain[i].Gol, &pemain[i].Assist)
	}
	return pemain
}

func SelectionSort(pemain []Pemain) {
	n := len(pemain)
	for i := 0; i < n-1; i++ {
		maxIdx_2311102181 := i
		for j := i + 1; j < n; j++ {
			if pemain[j].Gol > pemain[maxIdx_2311102181].Gol ||
				(pemain[j].Gol == pemain[maxIdx_2311102181].Gol && pemain[j].Assist > pemain[maxIdx_2311102181].Assist) {
				maxIdx_2311102181 = j
			}
		}
		pemain[i], pemain[maxIdx_2311102181] = pemain[maxIdx_2311102181], pemain[i]
	}
}

func TampilkanData(pemain []Pemain) {
	fmt.Println("Peringkat pemain berdasarkan jumlah gol dan assist:")
	for _, p := range pemain {
		fmt.Printf("%s %d %d\n", p.Nama, p.Gol, p.Assist)
	}
}

func main() {
	var n int
	fmt.Print("Masukkan jumlah pemain: ")
	fmt.Scan(&n)

	pemain := InputData(n)

	SelectionSort(pemain)

	TampilkanData(pemain)
}

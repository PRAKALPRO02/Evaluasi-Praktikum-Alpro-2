
package main

import (
    "fmt"
)

func bilangan_2311102038(sum int) int {
    var num int
    fmt.Scan(&num) 
    if num < 0 {
        return sum
    }

    if num > 0 && num%4 == 0 {
        sum += num
    }
    return bilangan_2311102038(sum)
}

func main() {
    fmt.Println("Masukkan bilangan (negatif untuk berhenti):")
    result := bilangan_2311102038(0) 
    fmt.Println("Jumlah bilangan kelipatan 4:", result)
}

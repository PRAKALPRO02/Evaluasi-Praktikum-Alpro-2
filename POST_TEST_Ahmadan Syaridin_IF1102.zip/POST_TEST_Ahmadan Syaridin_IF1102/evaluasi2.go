package main

import (
    "fmt"
)

func hitungTotalBiaya_2311102038(jumlahMenu, jumlahOrang int, sisaMakanan bool) int {
    biaya := 10000

    if jumlahMenu > 3 {
        biaya += (jumlahMenu - 3) * 2500
    }

    if jumlahMenu > 50 {
        biaya = 100000
    }

    if sisaMakanan {
        biaya *= jumlahOrang
    }

    return biaya
}

func main() {
    var M int
    fmt.Print("Masukkan jumlah rombongan: ")
    fmt.Scan(&M)

    for i := 1; i <= M; i++ {
        var jumlahMenu, jumlahOrang, sisaInput int
        var sisaMakanan bool

        fmt.Printf("Masukkan jumlah menu, jumlah orang, dan status sisa makanan (0 tidak, 1 iya) untuk rombongan %d: ", i)
        fmt.Scan(&jumlahMenu, &jumlahOrang, &sisaInput)

        sisaMakanan = sisaInput == 1

        hitungTotalBiaya_2311102038 := hitungTotalBiaya_2311102038(jumlahMenu, jumlahOrang, sisaMakanan)

        fmt.Printf("Total biaya untuk rombongan %d: Rp %d\n", i, hitungTotalBiaya_2311102038)
    }
}
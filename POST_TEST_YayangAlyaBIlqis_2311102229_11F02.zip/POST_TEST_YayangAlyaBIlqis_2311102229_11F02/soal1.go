package main

import "fmt"

func main() {
	var jam229, menit, voucherDigit int
	var member bool

	fmt.Print("Masukkan durasi (jam): ")
	fmt.Scan(&jam229)

	fmt.Print("Masukkan durasi (menit): ")
	fmt.Scan(&menit)

	fmt.Print("Apakah member? (true/false): ")
	fmt.Scan(&member)

	fmt.Print("Masukkan nomor voucher (jika ada): ")
	fmt.Scan(&voucherDigit)

	totalMenit := jam229*60 + menit

	var biayaDasar int
	if member {
		biayaDasar = (totalMenit / 60) * 3500
	} else {
		biayaDasar = (totalMenit / 60) * 5000
	}

	var diskon float64 = 0
	if voucherDigit >= 5 && totalMenit > 180 {
		diskon = 0.1
	}

	biayaAkhir := biayaDasar * (1 - diskon)

	fmt.Printf("Biaya sewa setelah diskon (jika memenuhi syarat): Rp %.2f\n", biayaAkhir)
}

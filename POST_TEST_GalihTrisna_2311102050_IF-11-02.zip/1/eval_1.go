package main

import "fmt"

func main() {
  	var a, b, n_2311102050, ganjil int
	  fmt.Print("Masukkan nilai a : ")
	  fmt.Scan(&a)
	  fmt.Print("Masukkan nilai b : ")
	  fmt.Scan(&b)
	  if a > b {
		n_2311102050 = a-b
	  } else {
		n_2311102050 = b-a
	  }
	  for i := 0; i <= n_2311102050; i++ {
		if (a+i)%2 != 0 {
			ganjil += 1
		}
	  }
	  fmt.Println("Banyak angka ganjil :" ,ganjil)
}

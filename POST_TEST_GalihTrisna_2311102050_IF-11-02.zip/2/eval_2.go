package main

import "fmt"

func hitung (i int) {
	var jumlah_menu, jumlah_orang, biaya int
	var sisa_2311102050 bool
	fmt.Println("Masukkan jumlah menu, jumlah orang, dan status sisa makanan (0 untuk tidak, 1 untuk iya) : ")
	fmt.Scan(&jumlah_menu, &jumlah_orang, &sisa_2311102050)
	if jumlah_menu > 3 {
		biaya = 10000 + (2500*(jumlah_menu-3))
	}else {
		biaya = 10000
	}
	if jumlah_menu > 50 {
		biaya = 100000
	}
	if sisa_2311102050 == true {
		biaya = biaya*jumlah_orang
	}
	fmt.Println("Total biaya untuk rombongan",i, ":", biaya)
	
}

func main() {
  	var rombongan int
	fmt.Print("Masukkan jumlah rombongan : ")
	fmt.Scan(&rombongan)
	for i := 1; i <= rombongan; i++ {
		hitung(i)
	}
}

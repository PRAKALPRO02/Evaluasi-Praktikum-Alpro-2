package main

import "fmt"

func hitung (jumlah int) int{
	var n_2311102050 int
	fmt.Scan(&n_2311102050)
	if n_2311102050 < 0 {
		return jumlah
	}
	if n_2311102050%4 == 0 {
		jumlah += n_2311102050
	} 
	return hitung(jumlah)
	
}

func main() {
	fmt.Println("Masukkan bilangan (negatif untuk berhenti) : ")
	fmt.Print("Jumlah bilangan kelipatan 4 : ",hitung(0))
}

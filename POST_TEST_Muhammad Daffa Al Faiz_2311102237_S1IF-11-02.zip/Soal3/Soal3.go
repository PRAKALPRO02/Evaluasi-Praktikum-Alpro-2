package main

import "fmt"

func main() {
	var x, y, count int

	fmt.Print("Masukkan nilai x: ")
	fmt.Scan(&x)
	fmt.Print("Masukkan nilai y: ")
	fmt.Scan(&y)
	for i := 1; i <= 365; i++ {
		if i%x == 0 && i%y != 0 {
			count++
		}
	}
	fmt.Printf("jumlah pertemuan dalam setahun: %d\n", count)
}

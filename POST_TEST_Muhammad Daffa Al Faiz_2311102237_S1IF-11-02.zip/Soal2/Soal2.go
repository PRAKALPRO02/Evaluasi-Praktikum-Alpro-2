package main

import "fmt"

func bilanganSempurna(bilangan int) bool {
	nilai := 1
	for i := 2; i*i <= bilangan; i++ {
		if bilangan%i == 0 {
			nilai += i
			if i*i != bilangan {
				nilai += bilangan / i
			}
		}
	}
	return nilai == bilangan
}

func is(bilangan int) bool {
	if bilangan <= 1 {
		return false
	}
	for i := 2; i*i <= bilangan; i++ {
		if bilangan%i == 0 {
			return false
		}
	}
	return true
}

func findPerfectNumbers(a, b int) {
	fmt.Printf("Numbers antara %d dan %d:\n", a, b)
	for i := a; i <= b; i++ {
		if bilanganSempurna(i) {
			fmt.Printf("%d ", i)
		}
	}
	fmt.Println()
}

func main() {
	var a, b int
	fmt.Print("Masukan nilai a: ")
	fmt.Scan(&a)
	fmt.Print("Masukan nilai b: ")
	fmt.Scan(&b)
	findPerfectNumbers(a, b)
}

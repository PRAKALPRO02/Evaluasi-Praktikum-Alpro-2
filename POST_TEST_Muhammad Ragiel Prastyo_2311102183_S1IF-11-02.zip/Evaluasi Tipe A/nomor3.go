// MUHAMMAD RAGIEL PRASTYO
// 2311102183
package main 
import "fmt" 

func main() { 
        var x, y, count_2311102183 int 

        fmt.Print("Masukkan nilai x: ") 
        fmt.Scan(&x) 

        fmt.Print("Masukkan nilai y: ") 
        fmt.Scan(&y) 

        for i := 1; i <= 365; i++ { 
                if i%x == 0 && i%y != 0 { 
                        count_2311102183++ 
                } 
        } 

        fmt.Printf("Jumlah pertemuan dalam setahun: %d\n", count_2311102183) 
} 
// MUHAMMAD RAGIEL PRASTYO
// 2311102183
package main
import (
	"fmt"
)

func isPerfectNumber(n int) bool {
	sum := 0
	for i := 1; i <= n/2; i++ {
		if n%i == 0 {
			sum += i
		}
	}
	return sum == n
}

func findPerfectNumbers(a, b int) []int {
	var perfectNumbers_2311102183 []int
	for i := a; i <= b; i++ {
		if isPerfectNumber(i) {
			perfectNumbers_2311102183 = append(perfectNumbers_2311102183, i)
		}
	}
	return perfectNumbers_2311102183
}

func main() {
	var a, b int

	fmt.Print("Masukkan nilai a: ")
	fmt.Scanln(&a)
	fmt.Print("Masukkan nilai b: ")
	fmt.Scanln(&b)

	perfectNumbers_2311102183 := findPerfectNumbers(a, b)

	fmt.Printf("Perfect numbers antara %d dan %d: ", a, b)
	for _, num := range perfectNumbers_2311102183 {
		fmt.Printf("%d ", num)
	}
	fmt.Println()
}
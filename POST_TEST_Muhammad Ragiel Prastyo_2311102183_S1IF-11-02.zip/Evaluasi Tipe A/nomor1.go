// MUHAMMAD RAGIEL PRASTYO
// 2311102183
package main
import (
    "fmt"
)

func hitungDurasiSewa(jam_2311102183, menit int) float64 {
    if jam_2311102183 < 1 {
        return 1.0
    }

    if menit >= 10 {
        return float64(jam_2311102183) + 1
    }
    return float64(jam_2311102183)
}

func hitungJumlahDigit(nomor string) int {
    return len(nomor)
}

func hitungBiayaSewa(durasi float64, isMember bool) float64 {
    tarifPerJam := 5000.0
    if isMember {
        tarifPerJam = 3500.0
    }
    return durasi * tarifPerJam
}

func main() {
    var jam_2311102183, menit int
    var isMember bool
    var nomorVoucher string

    fmt.Print("Masukkan durasi (jam): ")
    fmt.Scan(&jam_2311102183)

    fmt.Print("Masukkan durasi (menit): ")
    fmt.Scan(&menit)

    fmt.Print("Apakah member? (true/false): ")
    fmt.Scan(&isMember)

    fmt.Print("Masukkan nomor voucher (jika ada): ")
    fmt.Scan(&nomorVoucher)

    durasiEfektif := hitungDurasiSewa(jam_2311102183, menit)

    biaya := hitungBiayaSewa(durasiEfektif, isMember)

    jumlahDigit := hitungJumlahDigit(nomorVoucher)
    if jumlahDigit == 5 || jumlahDigit == 6 {
        diskon := biaya * 0.1
        biaya = biaya - diskon
    }

    fmt.Printf("Biaya sewa setelah diskon (jika memenuhi syarat): Rp %.2f\n", biaya)
}
package main

import "fmt"

func isPerfectNumber(num int) bool {
	// Fungsi untuk memeriksa apakah Perfect Number
	sum := 1
	for i := 2; i*i <= num; i++ {
		if num%i == 0 {
			sum += i
			if i*i != num {
				sum += num / i
			}
		}
	}
	return sum == num
}

func findPerfectNumbers(a, b int) {
	// Fungsi untuk mencari Perfect Number dalam rentang a sampai b
	fmt.Printf("Perfect numbers antara %d dan %d: ", a, b)
	found := false
	for i := a; i <= b; i++ {
		if isPerfectNumber(i) {
			fmt.Printf("%d ", i)
			found = true
		}
	}
	if !found {
		fmt.Println("Tidak ada bilangan sempurna ditemukan")
	}
}

func main() {
	var a, b int
	fmt.Print("Nilai a: ")
	fmt.Scan(&a)
	fmt.Print("Nilai b: ")
	fmt.Scan(&b)

	findPerfectNumbers(a, b)
}

// Zahrina Antika Malahati_2311102109

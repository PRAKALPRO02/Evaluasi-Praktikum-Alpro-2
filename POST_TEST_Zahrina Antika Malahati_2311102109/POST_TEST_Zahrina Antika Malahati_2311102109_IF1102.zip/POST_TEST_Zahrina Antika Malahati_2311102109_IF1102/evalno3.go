package main

import "fmt"

func main() {
	var x, y, count int
	// Memasukkan nilai dari x (berupa bilangan positif)
	fmt.Print("Masukkan nilai x: ")
	fmt.Scan(&x)
	// Memasukkan nilai dari y (berupa bilangan positif)
	fmt.Print("Masukkan nilai y: ")
	fmt.Scan(&y)

	for i := 1; i <= 365; i++ {
		if i%x == 0 && i%y != 0 {
			count++
		}
	}

	// Jumlah hari pertemuan rahasia dalam setahun
	fmt.Printf("Jumlah pertemuan dalam setahun: %d\n", count)
}

// Zahrina Antika Malahati_2311102109

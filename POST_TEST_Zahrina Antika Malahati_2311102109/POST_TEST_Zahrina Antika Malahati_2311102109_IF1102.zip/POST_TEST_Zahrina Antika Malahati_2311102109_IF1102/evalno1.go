package main

import (
	"fmt"
)

// Fungsi untuk menghitung biaya parkir
func hitungBiayaParkir(jam, menit int, jenisMembership string, isMember bool) int {
	// Tentukan tarif per jam berdasarkan jenis member
	var tarifPerJam float64
	if jenisMembership == "member" {
		tarifPerJam = 3500
	} else if jenisMembership == "nonmember" {
		tarifPerJam = 5000
	} else {
		fmt.Println("Jenis kendaraan tidak valid.")
		return 0
	}

	// Konversi durasi parkir ke jam (perhatikan aturan 60 menit)
	totalJam := float64(jam)
	if menit >= 60 {
		totalJam += 1
	}

	// Hitung biaya sebelum diskon
	totalBiaya := totalJam * tarifPerJam

	// Diskon 10% jika lebih dari 3 jam parkir
	if totalJam > 3 {
		totalBiaya *= 0.90
	}

	// Bulatkan ke bawah ke bilangan bulat
	return int(totalBiaya)
}

func main() {
	// Input dari pengguna
	var jam, menit int
	var jenisMembership string
	var isMember bool

	fmt.Print("Masukkan durasi parkir (jam): ")
	fmt.Scan(&jam)
	fmt.Print("Masukkan durasi parkir (menit): ")
	fmt.Scan(&menit)
	fmt.Print("Masukkan jenis Membership : ")
	fmt.Scan(&jenisMembership)
	fmt.Print("Apakah Anda member? (true/false): ")
	fmt.Scan(&isMember)

	// Hitung biaya parkir
	biaya := hitungBiayaParkir(jam, menit, jenisMembership, isMember)

	// Output biaya parkir
	fmt.Printf("Biaya parkir: Rp %d\n", biaya)
}

// Zahrina Antika Malahati_2311102109

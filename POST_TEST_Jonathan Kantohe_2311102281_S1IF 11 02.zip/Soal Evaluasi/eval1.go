// Jonathan Kantohe
// 2311102281

package main

import (
        "fmt"
)

func hitungBiayaSewa(jam, menit int, isMember bool, voucher string) float64 {
        //Tarif dasar berdasarkan status membership
        var tarifDasar float64
        if isMember {
                tarifDasar = 3500 //Memeber
        } else {
                tarifDasar = 5000 //NonMember
        }

        //Hitung durasi dalam menit
        durasiMenit := jam*60 + menit

        //Tambahkan 1 jam jika durasi menit lebih dari 30 dan jam kurang dari 1
        if durasiMenit > 30 && jam < 1 {
                jam++
        }

        //Hitung biaya sewa dasar
        biayaSewa := float64(jam) * tarifDasar

        //Cek apakah ada diskon voucher
        if len(voucher) >= 5 && len(voucher) <= 6 {
                biayaSewa *= 0.9 // Diskon 10%
        }

        return biayaSewa
}

func main() {
        var jam, menit int
        var isMember bool
        var voucher string

        fmt.Print("Masukkan durasi (jam): ")
        fmt.Scan(&jam)
        fmt.Print("Masukkan durasi (menit): ")
        fmt.Scan(&menit)
        fmt.Print("Apakah member? (true/false): ")
        fmt.Scan(&isMember)
        fmt.Print("Masukkan nomor voucher (jika ada): ")
        fmt.Scan(&voucher)

        biayaSewa := hitungBiayaSewa(jam, menit, isMember, voucher)

        fmt.Printf("Biaya sewa setelah diskon (jika memenuhi syarat): Rp %.2f\n", biayaSewa)
}
package main

import (
	"fmt"
	"strconv"
)

func perfectNum(n int) bool {
	var count int
	for i := 1; i < n; i++ {
		if n%i == 0 {
			count += i
		}
	}
	return count == n
}

func checkRangeNum(range1, range2 int) string {
	var result_2311102055 string
	for i := range1; i <= range2; i++ {
		if perfectNum(i) {
			result_2311102055 += strconv.Itoa(i) + " "
		}
	}
	return result_2311102055
}

func main() {
	var rangeA, rangeB int

	fmt.Print("Masukkan nilai a : ")
	fmt.Scan(&rangeA)
	fmt.Print("Masukkan nilai b : ")
	fmt.Scan(&rangeB)
	if rangeA <= rangeB {
		fmt.Printf("Perfect numbers antara %d dan %d: %s\n", rangeA, rangeB, checkRangeNum(rangeA, rangeB))
	} else {
		fmt.Println("kondisi a <= b tidak terpenuhi")
	}
}

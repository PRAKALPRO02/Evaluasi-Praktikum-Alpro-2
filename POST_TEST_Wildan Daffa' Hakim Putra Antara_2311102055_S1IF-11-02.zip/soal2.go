package main

import (
	"fmt"
	"strconv"
)

func perfectNum(n int) bool {
	var count int
	for i := 1; i < n; i++ {
		if n%i == 0 {
			count += i
		}
	}
	return count == n
}

func main() {
	var rangeA, rangeB int
	var result string
	fmt.Print("Masukkan nilai a : ")
	fmt.Scan(&rangeA)
	fmt.Print("Masukkan nilai b : ")
	fmt.Scan(&rangeB)
	if rangeA <= rangeB {
		for i := rangeA; i <= rangeB; i++ {
			if perfectNum(i) {
				result += strconv.Itoa(i) + " "
			}
		}
		fmt.Printf("Perfect numbers antara %d dan %d: %s\n", rangeA, rangeB, result)
	} else {
		fmt.Println("kondisi a <= b tidak terpenuhi")
	}
}

package main

import "fmt"

func hariBertemu(x, y, hari int, counter *int) {
	if hari%x == 0 && hari%y != 0 {
		*counter++
	}
	if hari == 365 {
		return
	} else {
		hariBertemu(x, y, hari+1, counter)
	}

}

func main() {
	var x_2311102055, y, count int
	fmt.Print("masukkan nilai x : ")
	fmt.Scan(&x_2311102055)
	fmt.Print("masukkan nilai y : ")
	fmt.Scan(&y)
	hariBertemu(x_2311102055, y, 1, &count)
	fmt.Println("jumlah pertemuan dalam setahun : ", count)
}

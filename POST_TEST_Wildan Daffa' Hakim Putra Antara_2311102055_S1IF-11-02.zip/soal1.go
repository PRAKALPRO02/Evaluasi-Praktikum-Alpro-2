package main

import "fmt"

func main() {
	var jam, menit int
	var hasil float64
	var no_voucher string
	var member bool

	fmt.Print("Masukkan durasi (jam): ")
	fmt.Scan(&jam)
	fmt.Print("Masukkan durasi (menit): ")
	fmt.Scan(&menit)
	fmt.Print("Apakah member? (true/false):")
	fmt.Scan(&member)
	fmt.Print("Masukkan nomor voucher (jika ada): ")
	fmt.Scan(&no_voucher)

	if member {
		hasil = float64(jam) * 3500
		if menit >= 10 {
			hasil += (float64(menit) / 60) * 3500
		}
	} else {
		hasil = float64(jam) * 5000
		if menit >= 10 {
			hasil += (float64(menit) / 60) * 5000
		}
	}

	if (len(no_voucher) == 5 || len(no_voucher) == 6) && (jam*60+menit) > 180 {
		hasil = hasil * (90.0 / 100.0)
	}

	fmt.Printf("Biaya sewa setelah diskon (jika memenuhi syarat): %.2f \n", hasil)
}

// Fajar Farizqi Azmi
// 2311102192
// IF-11-02

package main

import "fmt"

func jumlahKelipatan4Iteratif(bilangan2311102192 []int) int {
        jumlah := 0
        for _, angka := range bilangan2311102192 {
                if angka < 0 {
                        break
                }
                if angka%4 == 0 {
                        jumlah += angka
                }
        }
        return jumlah
}

func jumlahKelipatan4Rekursif(bilangan2311102192 []int, index int, jumlah int) int {
        if index >= len(bilangan2311102192) || bilangan2311102192[index] < 0 {
                return jumlah
        }
        if bilangan2311102192 [index]%4 == 0 {
                jumlah += bilangan2311102192[index]
        }
        return jumlahKelipatan4Rekursif(bilangan2311102192, index+1, jumlah)
}

func main () {
        var bilangan2311102192 []int
        var angka int

        fmt.Println("Masukkan bilangan (negatif untuk berhenti):")
        for {
                fmt.Scan(&angka)
                if angka < 0 {
                        break
                }
                bilangan2311102192 = append(bilangan2311102192, angka)
        }

        jumlahIteratif := jumlahKelipatan4Iteratif(bilangan2311102192)
        fmt.Println("Jumlah bilangan kelipatan 4 (iteratif):", jumlahIteratif)
		
}
// Fajar FArizqi Azmi
//2311102192


package main

import "fmt"

func hitungBiaya(jumlahMenu2311102192 int, jumlahOrang int) int {
        var biaya int

        if jumlahMenu2311102192 <= 3 {
                biaya = 10000
        } else if jumlahMenu2311102192 <= 50 {

                biaya = 10000 + (jumlahMenu2311102192-3) * 2500
        } else { 
                biaya = 100000
        }

        if jumlahMenu2311102192 > 0 {
                biaya *= jumlahOrang
        }

        return biaya
}

func main() {
        var jumlahMenu, jumlahOrang int

        fmt.Print("Masukkan jumlah menu: ")
        fmt.Scan(&jumlahMenu)

        fmt.Print("Masukkan jumlah orang: ")
        fmt.Scan(&jumlahOrang)

        totalBiaya := hitungBiaya(jumlahMenu, jumlahOrang)
        fmt.Println("Total biaya: Rp", totalBiaya)
}
// Fajar farizqi azmi
// 2311102192

package main

import "fmt"

func countOddNumbers(a2311102192, b int) int {
    count := 0
    for i := a2311102192; i <= b; i++ {
        if i%2 != 0 {
            count++
        }
    }
    return count
}

func main () {
    var a2311102192, b int
    fmt.Print("Masukkan nilai a: ")
    fmt.Scan(&a2311102192)
    fmt.Print("Masukkan nilai b: ")
    fmt.Scan(&b)

    if a2311102192 > b {
        a2311102192, b = b, a2311102192
    }

    oddCount := countOddNumbers(a2311102192, b)
    fmt.Println("Banyaknya angka ganjil:", oddCount)
}
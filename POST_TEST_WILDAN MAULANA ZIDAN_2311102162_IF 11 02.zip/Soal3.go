package main

import "fmt"

func kelipatan4_162(nums []int) int {
	if len(nums) == 0 {
		return 0
	}
	if nums[0] > 0 && nums[0]%4 == 0 {
		return nums[0] + kelipatan4_162(nums[1:])
	}
	return kelipatan4_162(nums[1:])
}

func main() {
	number_162 := []int{}
	var input int

	fmt.Println("input bilangan negatif untuk berhenti")

	for {
		fmt.Scan(&input)
		if input < 0 {
			break
		}
		number_162 = append(number_162, input)
	}

	result := kelipatan4_162(number_162)
	fmt.Printf("jumlh bilangan kelipatan 4 =  %d\n", result)
}

// 2311102162
package main

import "fmt"

func main() {
	var a, b int
	fmt.Print("masukan nilai a:")
	fmt.Scan(&a)
	fmt.Print("masukan nilai b:")
	fmt.Scan(&b)

	if a > b {
		fmt.Println("nilai a harus lebih kecil dari b")
		return
	}
	count := 0
	for i := a; i <= b; i++ {
		if i%2 != 0 {
			count++
		}
	}
	fmt.Printf("banyak angka ganjil : %d\n", count)
}

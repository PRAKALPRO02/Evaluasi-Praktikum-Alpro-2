package main

import "fmt"

func hitungBiaya_162(jumlah_menu_162 int, jumlah_orang_162 int) int {
	var biaya int

	if jumlah_menu_162 <= 3 {
		biaya = 10000
	} else if jumlah_menu_162 <= 50 {

		biaya = 10000 + (jumlah_menu_162-3)*2500
	} else {
		biaya = 100000
	}

	if jumlah_menu_162 > 0 {
		biaya *= jumlah_orang_162
	}

	return biaya
}

func main() {
	var jumlah_menu_162, jumlah_orang_162 int

	fmt.Print("masukan jumlah menu: ")
	fmt.Scan(&jumlah_menu_162)

	fmt.Print("masukan jumlah orang: ")
	fmt.Scan(&jumlah_orang_162)

	totalBiaya := hitungBiaya_162(jumlah_menu_162, jumlah_orang_162)
	fmt.Println("Total biaya: Rp", totalBiaya)
}

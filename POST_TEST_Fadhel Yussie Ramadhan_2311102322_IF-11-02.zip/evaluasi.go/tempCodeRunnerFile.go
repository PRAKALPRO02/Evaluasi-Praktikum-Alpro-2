func main() {

    var jam, m int
	fmt.Print("masukkan jumlah rombongan: ")
	fmt.Scanln(&m)

	for i : 1;i <= m; i++ {
		var menu, banyakOrang, sisa int
		fmt.Printf ("masukkan jumlah menu")
		fmt.Scan (menu)
	}

}

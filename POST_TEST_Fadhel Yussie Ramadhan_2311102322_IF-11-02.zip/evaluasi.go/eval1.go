package main

import "fmt"


func main () {
	var a,b int
	fmt.Print ("masukkan nilai a: ")
	fmt.Scan (&a)
	fmt.Print ("masukkan nilai b: ")
	fmt.Scan (&b)

	jumlahGanjil := (b-a+1)/2
	
	fmt.Printf ("Banyaknya bilangan ganjil: ", jumlahGanjil)

}

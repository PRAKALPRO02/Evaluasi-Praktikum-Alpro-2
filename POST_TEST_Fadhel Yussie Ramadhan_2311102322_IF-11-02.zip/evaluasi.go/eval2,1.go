package main

import "fmt"

func main() {
    var m int
    fmt.Print("Masukkan jumlah rombongan: ")
    fmt.Scanln(&m)

    for i := 1; i <= m; i++ {
        var menu, orang, sisa int
        fmt.Printf("Masukkan jumlah menu, jumlah orang, dan status sisa makanan (0 tidak ada sisa dan 1 ada sisa) untuk rombongan %d: ", i)
        fmt.Scanln(&menu, &orang, &sisa)

        biaya := hitungBiayaMakan(menu, orang, sisa == 1)

        fmt.Printf("Total biaya rombongan %d : rp %d\n", i, biaya)
    }
}

func hitungBiayaMakan(menu int, orang int, sisa bool) int {
    var biaya int

    if menu <= 3 {
        biaya = 10000
    } else if menu <= 50 {
        biaya = 10000 + (menu-3)*2500
    } else {
        biaya = 100000
    }

    if sisa {
        biaya *= orang
    }

    return biaya
}
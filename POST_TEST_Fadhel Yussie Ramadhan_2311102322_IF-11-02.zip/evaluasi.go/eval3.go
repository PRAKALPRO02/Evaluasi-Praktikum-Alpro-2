package main

import "fmt"

func main() {
    var angka, jumlah int

    fmt.Println("Masukkan bilangan (untuk berhenti pakai bil negatif):")
    for {
        fmt.Scan(&angka)
        if angka < 0 {
            break
        }
        jumlah = jumlah4xRekusrif(angka, jumlah)
    }

    fmt.Printf("Jumlah bilangan kelipatan 4: %d\n", jumlah)
}

func jumlah4xRekusrif(angka int, jumlah int) int {
    if angka < 0 {
        return jumlah
    }

    if angka%4 == 0 {
        jumlah += angka
    }

    return jumlah4xRekusrif(angka-1, jumlah)
}
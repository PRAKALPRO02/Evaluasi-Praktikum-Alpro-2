package main
import (
"fmt"
)
func isPerfectNumber(n int) bool {
sum_2311102077 := 0
for i := 1; i < n; i++ {
if n%i == 0 {
sum_2311102077 += i
}
}
return sum_2311102077 == n
}
func findPerfectNumbers(a, b int) {
fmt.Printf("Perfect numbers antara %d dan %d: ", a, b)
found := false
for i := a; i <= b; i++ {
if isPerfectNumber(i) {
fmt.Printf("%d ", i)
found = true
}
}
if !found {
fmt.Println("Tidak ada perfect number pada rentang ini.")
} else {
	fmt.Println()
	}
	}
	func main() {
	var a, b int
	fmt.Print("Masukkan nilai a: ")
fmt.Scan(&a)
fmt.Print("Masukkan nilai b: ")
fmt.Scan(&b)
findPerfectNumbers(a, b)
}
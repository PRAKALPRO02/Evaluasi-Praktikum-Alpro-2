package main

import (
	"fmt"
)

const (
	
	memberRate    = 3000 
	nonMemberRate = 5000  
)

func calculateRentalCost(jam, minutes int, isMember bool, voucher string) float64 {
	totalJam := jam
	if minutes >= 10 {
		totalJam += 1
	}
	rate := nonMemberRate
	if isMember {
		rate = memberRate
	}
	totalCost := float64(totalJam * rate)
	
	if totalJam > 3 && len(voucher) > 0 {
		lastDigit := voucher[len(voucher)-1:]
		if lastDigit == "5" || lastDigit == "6" {
			totalCost *= 0.9 
		}
	}
	
	return totalCost
}

func main() {
	var jam, minutes int
	var isMember bool
	var voucher string
	fmt.Print("Masukkan durasi (jam): ")
	fmt.Scan(&jam)
	fmt.Print("Masukkan durasi (menit): ")
	fmt.Scan(&minutes)
	fmt.Print("Apakah member? (true/false): ")
	fmt.Scan(&isMember)
	fmt.Print("Masukkan nomor voucher (jika ada): ")
	fmt.Scan(&voucher)
	totalCost := calculateRentalCost(jam, minutes, isMember, voucher)
	fmt.Printf("Biaya sewa setelah diskon (jika memenuhi syarat): Rp %.2f\n", totalCost)
}

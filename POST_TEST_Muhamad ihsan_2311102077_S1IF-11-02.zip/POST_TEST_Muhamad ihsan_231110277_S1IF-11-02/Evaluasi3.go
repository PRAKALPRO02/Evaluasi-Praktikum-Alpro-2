package main

import "fmt"

func main() {
	var x_2311102077, y, count int
	fmt.Print("Masukkan nilai x: ")
	fmt.Scan(&x_2311102077)
	fmt.Print("Masukkan nilai y: ")
	fmt.Scan(&y)
for i := 1; i <= 365; i++ {
	if i%x_2311102077 == 0 && i%y != 0 {
	count++
}
}
	fmt.Printf("Jumlah pertemuan dalam setahun: %d\n", count)
}
package main

import "fmt"

func main() {
	var rombongan int
	var jumlahMenu, orang, sisa int

	const hargaBiasa = 10000
	const hargaPerMenu = 2500
	const hargaMaks = 50000

	fmt.Print("Masukkan jumlah rombongan: ")
	fmt.Scan(&rombongan)

	for i := 1; i <= rombongan; i++ {
		fmt.Printf("Masukkan jumlah menu, jumlah orang, dan status sisa makanan (0 untuk tidak, 1 untuk iya)\n: ")
		fmt.Scan(&jumlahMenu, &orang, &sisa)
		
		
		totalHarga := hargaBiasa
		if jumlahMenu > 3 {
			totalHarga += (jumlahMenu - 3) * hargaPerMenu
		}
		
		totalHarga *= orang

		if sisa == 1 {
			totalHarga += orang * hargaMaks
		}

		fmt.Printf("Total biaya untuk rombongan %d: Rp %d\n", i, totalHarga)
	}
}

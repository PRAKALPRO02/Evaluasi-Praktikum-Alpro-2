package main
import "fmt"

func main () {
	var rombongan int
	var jumlahMenu_2311102064,orang int
	var sisa int

	const hargaBiasa = 10000
	const hargaPerMenu = 2500
	const hargaMaks = 5000

	fmt.Print("Masukan jumlah Rombongan:")
	fmt.Scan(&rombongan)

	for i:=1; i<= rombongan; i++ {
		fmt.Printf("Masukan jumlah menu, jumlah orang, dan statussisa makanan (0 untuk tidak, 1 untuk iya)", i)
		fmt.Scan(&jumlahMenu_2311102064,&orang,&sisa)
	total harga:= harga Biasa
	if jumlah Menu_2311102064 > 3 {
		totalharga += (jumlahMenu_2311102064 - 3)*
		hargaPerMenu
	}
totalHarga *=orang
if sisa == 1{
totalHarga +=orang* totalHarga
}

fmt.print("Total Biaya untuk rombongan %d : Rp%d/n,i,totalHarga")
}
}
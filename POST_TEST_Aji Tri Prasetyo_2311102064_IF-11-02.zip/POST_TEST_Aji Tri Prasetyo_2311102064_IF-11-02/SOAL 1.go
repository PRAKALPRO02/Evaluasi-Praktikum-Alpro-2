package main

import "fmt"

func main () {
	var a, b int

	fmt.Print("Masukan nilaia:")
	fmt.Scan(&a)

	fmt.Print("Masukan nilaib:")
	fmt.Scan(&b)
	count:i=0
	for i:=a;i<=b; i++ {
		if i%2 != 0 {
			count ++

	}
}

      fmt.Print("Banyaknya angka ganjil: d/n%", totalGanjil_2311102064)
]

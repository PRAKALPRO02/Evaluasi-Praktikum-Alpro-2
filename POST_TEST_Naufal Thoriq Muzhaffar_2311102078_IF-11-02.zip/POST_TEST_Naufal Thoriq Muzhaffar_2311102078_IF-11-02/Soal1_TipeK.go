package main

import "fmt"

func main() {
	var N_2311102078 int
	fmt.Print("Masukkan jumlah peserta: ")
	fmt.Scan(&N_2311102078)
	jumHadiahA := 0
	jumHadiahB := 0
	jumHadiahC := 0

	for i := 1; i <= N_2311102078; i++ {
		var kartu int
		fmt.Printf("Masukkan nomor kartu peserta ke-%d: ", i)
		fmt.Scan(&kartu)
		hadiah := cekHadiah(kartu)
		fmt.Println(hadiah)

		switch hadiah {
		case "Hadiah A":
			jumHadiahA++
		case "Hadiah B":
			jumHadiahB++
		case "Hadiah C":
			jumHadiahC++
		}
	}
	fmt.Printf("\nJumlah yang diperoleh Hadiah A: %d\n", jumHadiahA)
	fmt.Printf("Jumlah yang diperoleh Hadiah B: %d\n", jumHadiahB)
	fmt.Printf("Jumlah yang diperoleh Hadiah C: %d\n", jumHadiahC)
}

func cekHadiah(kartu int) string {
	sama := true
	beda := true
	digit := make(map[int]bool)
	digitPrev := -1

	for kartu > 0 {
		digitCurr := kartu % 10
		if digitPrev != -1 && digitCurr != digitPrev {
			sama = false
		}
		if digit[digitCurr] {
			beda = false
		}
		digit[digitCurr] = true
		digitPrev = digitCurr
		kartu /= 10
	}

	if sama {
		return "Hadiah A"
	} else if beda {
		return "Hadiah B"
	} else {
		return "Hadiah C"
	}
}

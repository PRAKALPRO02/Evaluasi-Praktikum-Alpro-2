package main

import "fmt"

func main() {
	var n, m int
	fmt.Print("Masukkan bilangan n: ")
	fmt.Scanln(&n)
	fmt.Print("Masukkan bilangan m: ")
	fmt.Scanln(&m)
	fmt.Printf("Hasil dari %d x %d = %d", n, m, perkalian_2311102078(n, m))
}

func perkalian_2311102078(n, m int) int {
	if n == 1 {
		return m
	} else if n != 0 {
		return m + perkalian_2311102078(n-1, m)
	} else {
		return 0
	}
}

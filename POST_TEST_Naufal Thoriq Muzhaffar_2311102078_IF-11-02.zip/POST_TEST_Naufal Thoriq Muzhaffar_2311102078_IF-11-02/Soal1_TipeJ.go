package main

import "fmt"

func main() {
	var input_2311102078 int
	fmt.Print("Masukkan bilangan bulat positif (>10): ")
	fmt.Scan(&input_2311102078)
	jumDigit := 0
	tampung := input_2311102078
	for tampung > 0 {
		jumDigit++
		tampung /= 10
	}
	tengah := jumDigit / 2
	if jumDigit%2 != 0 {
		tengah++
	}
	bilangan1, bilangan2 := 0, 0
	tampung = input_2311102078
	for i := 0; i < jumDigit; i++ {
		digit := tampung / posisiTengah(10, jumDigit-i-1) % 10
		if i < tengah {
			bilangan1 = bilangan1*10 + digit
		} else {
			bilangan2 = bilangan2*10 + digit
		}
	}
	hasil := bilangan1 + bilangan2
	fmt.Printf("Bilangan 1: %d\n", bilangan1)
	fmt.Printf("Bilangan 2: %d\n", bilangan2)
	fmt.Printf("Hasil penjumlahan: %d\n", hasil)
}

func posisiTengah(nilai, digit int) int {
	hasil := 1
	for i := 0; i < digit; i++ {
		hasil *= nilai
	}
	return hasil
}

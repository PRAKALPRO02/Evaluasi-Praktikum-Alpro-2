package main

import "fmt"

func main() {
	const DAYS_2311102053 int = 365
	var x, y, count int
	fmt.Print("Masukan nila x: ")
	fmt.Scanln(&x)
	fmt.Print("Masukan nila y: ")
	fmt.Scanln(&y)
	for i := 1; i <= DAYS_2311102053; i++ {
		if i%x == 0 && i%y != 0 {
			count++
		}
	}
	fmt.Printf("Jumlah pertemuan rahasia dalam setahun adalah: %v", count)
}

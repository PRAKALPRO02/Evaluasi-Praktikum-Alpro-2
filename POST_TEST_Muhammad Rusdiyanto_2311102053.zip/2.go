package main

import "fmt"

func totalFactorial(x int) int {
	var total int = 0
	for i := 1; i < x; i++ {
		if x%i == 0 {
			total += i
		}
	}
	return total
}

func perfectNumbers(a int, b int) {
	fmt.Print("Perfect numbers antara 3 dan 13: ")
	for i := a; i <= b; i++ {
		if totalFactorial(i) == i {
			fmt.Printf("%v ", i)
		}
	}
}

func main() {
	var a_2311102053, b int
	fmt.Print("Masukan nilai a: ")
	fmt.Scanln(&a_2311102053)
	fmt.Print("Masukan nilai b: ")
	fmt.Scanln(&b)
	if a_2311102053 <= b {
		perfectNumbers(a_2311102053, b)
	} else {
		fmt.Println("A harus lebih dari B")
	}
}

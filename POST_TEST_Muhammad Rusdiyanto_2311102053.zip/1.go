package main

import "fmt"

func total(jam int, menit int, member string, voucher int) {
	var total float64
	if jam < 1 {
		if member == "true" {
			total = 3500
		} else {
			total = 5000
		}
	} else {
		if member == "true" {
			total = float64(jam * 3500)
			if menit >= 10 {
				total += float64(menit) / 60 * 3500
			}
		} else {
			total = float64(jam * 5000)
			if menit >= 10 {
				total += float64(menit) / 60 * 5000
			}
		}

		if voucher > 9999 && voucher < 1000000 && jam >= 3 && menit > 0 {
			total = total * 0.9
		}
	}
	fmt.Printf("Biaya sewa setelah diskon (jika memenuhi syarat): Rp %v", total)
}

func main() {
	var jam, menit, voucher int
	var isMember_231102053 string
	fmt.Print("Masukan durasi (jam): ")
	fmt.Scanln(&jam)
	fmt.Print("Masukan durasi (menit): ")
	fmt.Scanln(&menit)
	fmt.Print("Apakah member? (true/false): ")
	fmt.Scanln(&isMember_231102053)
	fmt.Print("Masukan nomor voucher (jika ada): ")
	fmt.Scanln(&voucher)
	total(jam, menit, isMember_231102053, voucher)
}

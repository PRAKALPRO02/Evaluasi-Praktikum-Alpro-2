package main

import (
	"fmt"
	"strconv"
)

func hadiahKartu(kartu_2311102169 int) string {
	kartuStr := strconv.Itoa(kartu_2311102169)

	semuaSama := true
	semuaBerbeda := true
	for i := 1; i < len(kartuStr); i++ {
		if kartuStr[i] != kartuStr[i-1] {
			semuaSama = false
		}
		if kartuStr[i] == kartuStr[i-1] {
			semuaBerbeda = false
		}
	}

	if semuaSama {
		return "Hadiah A"
	}

	if semuaBerbeda {
		return "Hadiah B"
	}

	return "Hadiah C"
}

func main() {
	var n int
	fmt.Print("Masukkan jumlah peserta: ")
	fmt.Scanln(&n)

	hadiahCount := map[string]int{
		"Hadiah A": 0,
		"Hadiah B": 0,
		"Hadiah C": 0,
	}

	for i := 0; i < n; i++ {
		var kartu int
		fmt.Printf("Masukkan nomor kartu peserta %d: ", i+1)
		fmt.Scanln(&kartu)

		hasilHadiah := hadiahKartu(kartu)
		fmt.Printf("Peserta %d memperoleh %s\n", i+1, hasilHadiah)

		hadiahCount[hasilHadiah]++
	}

	fmt.Printf("Jumlah peserta yang memperoleh Hadiah A: %d\n", hadiahCount["Hadiah A"])
	fmt.Printf("Jumlah peserta yang memperoleh Hadiah B: %d\n", hadiahCount["Hadiah B"])
	fmt.Printf("Jumlah peserta yang memperoleh Hadiah C: %d\n", hadiahCount["Hadiah C"])
}

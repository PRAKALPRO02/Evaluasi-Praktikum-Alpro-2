package main

import "fmt"

func potongBilangan(bilangan_2311102169 int) (int, int) {
	bagian1 := bilangan_2311102169 % 10
	bagian2 := bilangan_2311102169 / 10

	return bagian1, bagian2
}

func main() {
	var bilangan_2311102169 int
	fmt.Print("Masukkan bilangan: ")
	fmt.Scan(&bilangan_2311102169)

	if bilangan_2311102169 < 10 {
		fmt.Print("bilangan <10 !!!")
	}

	bagian1, bagian2 := potongBilangan(bilangan_2311102169)

	hasilPenjumlahan := bagian1 + bagian2

	fmt.Println("Bilangan 1 :", bagian1)
	fmt.Println("Bilangan 1 :", bagian2)

	fmt.Print("Hasil penjumlahan : ", hasilPenjumlahan)
}

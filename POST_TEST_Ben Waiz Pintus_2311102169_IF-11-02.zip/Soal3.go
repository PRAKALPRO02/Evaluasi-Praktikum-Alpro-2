package main

import "fmt"

func main() {
	var angka1_2311102169, angka2_2311102169 int

	fmt.Print("Masukkan bilangan pertama: ")
	fmt.Scanln(&angka1_2311102169)

	fmt.Print("Masukkan bilangan kedua: ")
	fmt.Scanln(&angka2_2311102169)

	result := angka1_2311102169 * angka2_2311102169

	fmt.Printf("Hasil perkalian %d x %d = %d\n", angka1_2311102169, angka2_2311102169, result)
}

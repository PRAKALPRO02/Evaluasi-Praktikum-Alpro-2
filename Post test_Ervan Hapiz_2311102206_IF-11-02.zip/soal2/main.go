package main

import "fmt"

func digitsama(n_206 int) bool {
	digit_trakhir_206 := n_206 % 10
	for n_206 > 0 {
		if n_206%10 != digit_trakhir_206 {
			return false
		}
		n_206 /= 10
	}
	return true
}
func digitbeda(n_206 int) bool {
	digit_trakhir_206 := n_206 % 10
	n_206 /= 10
	for n_206 > 0 {
		if n_206%10 == digit_trakhir_206 {
			return false
		}
		n_206 /= 10
	}
	return true
}

func main() {
	var n_206 int

	fmt.Print("masukan jumlah anggota : ")
	fmt.Scan(&n_206)

	hadiahA := 0
	hadiahB := 0
	hadiahC := 0
	for i := 0; i < n_206; i++ {
		var nomer int
		fmt.Printf("nomer kartu orang ke-%d: ", i+1)
		fmt.Scan(&nomer)

		if digitsama(nomer) {
			fmt.Println("Hadiah A ")
			hadiahA += 1
		} else if digitbeda(nomer) {
			fmt.Println("Hadiah B ")
			hadiahB += 1
		} else {
			fmt.Println("Hadiah C ")
			hadiahC += 1
		}
	}
	fmt.Println()
	fmt.Println("Jumlah penonton Hadiah A : ", hadiahA)
	fmt.Println("Jumlah penonton Hadiah B : ", hadiahB)
	fmt.Println("Jumlah penonton Hadiah C : ", hadiahC)

}

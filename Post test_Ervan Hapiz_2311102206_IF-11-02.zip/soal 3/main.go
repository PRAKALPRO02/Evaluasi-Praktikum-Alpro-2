package main

import "fmt"

func perkalian(i_2311102206, n_2311102206 int) int {
	if n_2311102206 == 1 {
		return i_2311102206
	} else {
		return i_2311102206 + perkalian(i_2311102206, n_2311102206-1)
	}
}
func main() {
	var n_2311102206, i_2311102206 int
	fmt.Print("masukan n : ")
	fmt.Scan(&n_2311102206)
	fmt.Print("masukan m : ")
	fmt.Scan(&i_2311102206)
	hasil := perkalian(i_2311102206, n_2311102206)
	fmt.Printf("hasil dari %d X %d = %d", n_2311102206, i_2311102206, hasil)
}

package main

import (
	"fmt"
	"math"
)

func pemotong(n int) {
	for n < 10 {
		fmt.Println("Bilangan harus memiliki minimal 2 digit!!!")
		fmt.Print("Masukan bilangan bulat (>10): ")
		fmt.Scan(&n)
	}
	var bilangan1, bilangan2 int
	strpanjang := fmt.Sprint(n)
	panjang := len(strpanjang)
	if panjang%2 == 0 {
		bilangan1 = n / int(math.Pow(10.0, float64(panjang-2)))
		bilangan2 = n % int(math.Pow(10.0, float64(panjang-2)))
	}

	fmt.Println("Potongan bilangan : ", bilangan1, bilangan2)
	jumlah := bilangan1 + bilangan2

	fmt.Println("jumlah bilangan  : ", jumlah)
}
func main() {
	var n_231102206 int
	fmt.Print("Masukan bilangan bulat : ")
	fmt.Scan(&n_231102206)
	pemotong(n_231102206)
}

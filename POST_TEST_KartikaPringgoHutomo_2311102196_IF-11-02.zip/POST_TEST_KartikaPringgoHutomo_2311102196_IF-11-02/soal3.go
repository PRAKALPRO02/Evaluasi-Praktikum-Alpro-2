package main

import "fmt"

// Fungsi iteratif untuk mengalikan n * m dengan penjumlahan berulang
func multiply(n, m int) int {
	result_2311102196 := 0
	for m > 0 {
		result_2311102196 += n
		m--
	}
	return result_2311102196
}

func main() {
	var n, m int
	fmt.Print("Masukkan bilangan n: ")
	fmt.Scanln(&n)
	fmt.Print("Masukkan bilangan m: ")
	fmt.Scanln(&m)

	// Menghitung hasil perkalian
	result_2311102196 := multiply(n, m)
	fmt.Printf("Hasil dari %d x %d = %d\n", n, m, result_2311102196)
}
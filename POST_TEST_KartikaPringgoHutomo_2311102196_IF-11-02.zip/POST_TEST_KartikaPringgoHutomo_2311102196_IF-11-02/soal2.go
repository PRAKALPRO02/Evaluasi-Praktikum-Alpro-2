package main

import "fmt"


func isAllSameDigits(num int) bool {
	digit_2311102196 := num % 10
	for num /= 10; num > 0; num /= 10 {
		if num%10 != digit_2311102196 {
			return false
		}
	}
	return true
}

func isAllDifferentDigits(num int) bool {
	seen := 0
	for num > 0 {
		digit_2311102196 := num % 10
		if (seen>>digit_2311102196)&1 == 1 {
			return false
		}
		seen |= 1 << digit_2311102196
		num /= 10
	}
	return true
}

func main() {
	var numParticipants_2311102196, hadiahA, hadiahB, hadiahC int

	fmt.Print("Masukkan jumlah peserta: ")
	fmt.Scanln(&numParticipants_2311102196)

	for i := 1; i <= numParticipants_2311102196; i++ {
		var cardNumber int
		fmt.Printf("Masukkan nomor kartu peserta ke-%d: ", i)
		fmt.Scanln(&cardNumber)

		switch {
		case isAllSameDigits(cardNumber):
			fmt.Println("Hadiah A")
			hadiahA++
		case isAllDifferentDigits(cardNumber):
			fmt.Println("Hadiah B")
			hadiahB++
		default:
			fmt.Println("Hadiah C")
			hadiahC++
		}
	}

	fmt.Printf("Jumlah yang memperoleh Hadiah A: %d\n", hadiahA)
	fmt.Printf("Jumlah yang memperoleh Hadiah B: %d\n", hadiahB)
	fmt.Printf("Jumlah yang memperoleh Hadiah C: %d\n", hadiahC)
}
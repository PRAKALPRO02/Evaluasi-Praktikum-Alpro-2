package main

import "fmt"

func main() {
	var input int
	fmt.Print("Masukkan bilangan bulat positif (>10): ")
	fmt.Scanln(&input)

	strInput := fmt.Sprintf("%d", input)
	length := len(strInput)

	var left_2311102196, right int
	mid := length / 2

	if length%2 == 0 {
		fmt.Sscanf(strInput[:mid], "%d", &left_2311102196)
		fmt.Sscanf(strInput[mid:], "%d", &right)
	} else {
		fmt.Sscanf(strInput[:mid+1], "%d", &left_2311102196)
		fmt.Sscanf(strInput[mid+1:], "%d", &right)
	}

	fmt.Println("Bilangan 1:", left_2311102196)
	fmt.Println("Bilangan 2:", right)
	fmt.Println("Hasil penjumlahan:", left_2311102196+right)
}
package main

import "fmt"

func main() {
	var M int
	fmt.Println("Program Menghitung Total Biaya Makan di Restoran")
	fmt.Printf("Masukkan jumlah rombongan: ")
	fmt.Scan(&M)

	for i := 1; i <= M; i++ {
		var jumlahMenu_2311102046, jumlahOrang, sisaMakanan int
		fmt.Printf("Masukkan jumlah menu, jumlah orang, dan status sisa makanan (0 untuk tidak 1 untuk iya): ")
		fmt.Scan(&jumlahMenu_2311102046, &jumlahOrang, &sisaMakanan)

		var totalBiaya int
		if jumlahMenu_2311102046 > 50 {
			totalBiaya = 100000
		} else if jumlahMenu_2311102046 > 3 {
			totalBiaya = 10000 + (jumlahMenu_2311102046-3)*2500
		} else {
			totalBiaya = 10000
		}

		if sisaMakanan == 1 {
			totalBiaya *= jumlahOrang
		}
		fmt.Printf("Total biaya untuk rombongan %d: Rp %d\n", i, totalBiaya)
	}
}

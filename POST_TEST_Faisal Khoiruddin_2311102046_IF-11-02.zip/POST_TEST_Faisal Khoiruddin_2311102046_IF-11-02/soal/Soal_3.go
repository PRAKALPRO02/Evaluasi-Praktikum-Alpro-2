package main

import "fmt"

func penjumahan_kelipatan_4() int {
	var num_2311102046 int
	fmt.Scan(&num_2311102046)
	if num_2311102046 < 0 {
		return 0
	}

	if num_2311102046%4 == 0 {
		return num_2311102046 + penjumahan_kelipatan_4()
	}
	return penjumahan_kelipatan_4()
}

func main() {
	fmt.Println("Program JumlahBilangan Positif Kelipatan 4")
	fmt.Println("Masukkan bilangan (negatif untuk berhenti): ")
	sum := penjumahan_kelipatan_4()
	fmt.Println("jumlah bilangan kelipatan 4: ", sum)
}

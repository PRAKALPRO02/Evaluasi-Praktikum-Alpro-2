package main

import "fmt"

func main() {
	var a_2311102046, b int

	fmt.Println("Program Angka Ganjil dalam Rentang")
	fmt.Print("Masukkan nilai a: ")
	fmt.Scan(&a_2311102046)
	fmt.Print("Masukkan nilai b: ")
	fmt.Scan(&b)

	angka := 0
	for i := a_2311102046; i <= b; i++ {
		if i%2 != 0 {
			angka++
		}
	}
	fmt.Printf("Banyaknya angka ganjil : %d\n", angka)
}

package main

import "fmt"

func hitungGanjil2311102234(a, b int) int {
	count := 0
	for i := a; i <= b; i++ {
		if i%2 != 0 {
			count++
		}
	}
	return count
}

func main() {
	var a, b int
	fmt.Print("Masukkan bilangan positif pertama (a): ")
	fmt.Scan(&a)
	fmt.Print("Masukkan bilangan positif kedua (b): ")
	fmt.Scan(&b)

	if a > b {
		fmt.Println("Nilai a <= b.")
		return
	}

	jumlahGanjil2311102234 := hitungGanjil2311102234(a, b)
	fmt.Printf("Banyaknya bilangan ganjil dari %d hingga %d yaitu: %d\n", a, b, jumlahGanjil2311102234)
}

package main

import "fmt"

func hitungKelipatanEmpatRekursif234(total234 int) int {
	var angka234 int
	fmt.Print("Masukkan bilangan (negatif untuk berhenti): ")
	fmt.Scan(&angka234)

	if angka234 < 0 {
		return total234
	}

	if angka234 > 0 && angka234%4 == 0 {
		total234 += angka234
	}

	return hitungKelipatanEmpatRekursif234(total234)
}

func main() {
	hasil234 := hitungKelipatanEmpatRekursif234(0)
	fmt.Printf("Jumlah bilangan kelipatan 4: %d\n", hasil234)
}

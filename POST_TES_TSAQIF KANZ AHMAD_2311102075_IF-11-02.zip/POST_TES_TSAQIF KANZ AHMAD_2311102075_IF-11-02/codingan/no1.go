package main

import (
	"fmt"
)

// Fungsi untuk menghitung biaya parkir
func hitungBiayaParkir(jam, menit int, jenisKendaraan string, isMember bool) int {
	// Tentukan tarif per jam berdasarkan jenis kendaraan
	var tarifPerJam float64
	if jenisKendaraan == "biasa" {
		tarifPerJam = 3000
	} else if jenisKendaraan == "mewah" {
		tarifPerJam = 7000
	} else {
		fmt.Println("Jenis kendaraan tidak valid.")
		return 0
	}

	// Konversi durasi parkir ke jam (perhatikan aturan 30 menit)
	totalJam := float64(jam)
	if menit >= 30 {
		totalJam += 1
	} else if jam == 0 && menit > 0 {
		// Jika durasi kurang dari 1 jam, hitung sebagai 1 jam
		totalJam = 1
	}

	// Hitung biaya sebelum diskon
	totalBiaya := totalJam * tarifPerJam

	// Diskon 20% jika lebih dari 5 jam parkir
	if totalJam > 5 {
		totalBiaya *= 0.8
	}

	// Diskon tambahan 15% jika member
	if isMember {
		totalBiaya *= 0.85
	}

	// Bulatkan ke bawah ke bilangan bulat
	return int(totalBiaya)
}

func main() {
	// Input dari pengguna
	var jam, menit int
	var jenisKendaraan string
	var isMember bool

	fmt.Print("Masukkan durasi parkir (jam): ")
	fmt.Scan(&jam)
	fmt.Print("Masukkan durasi parkir (menit): ")
	fmt.Scan(&menit)
	fmt.Print("Masukkan jenis kendaraan (biasa/mewah): ")
	fmt.Scan(&jenisKendaraan)
	fmt.Print("Apakah Anda member? (true/false): ")
	fmt.Scan(&isMember)

	// Hitung biaya parkir
	biaya := hitungBiayaParkir(jam, menit, jenisKendaraan, isMember)

	// Output biaya parkir
	fmt.Printf("Biaya sewa: Rp %d\n", biaya)
}

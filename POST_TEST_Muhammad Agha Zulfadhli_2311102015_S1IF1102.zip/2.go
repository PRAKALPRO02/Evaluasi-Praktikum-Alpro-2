package main

import (
	"fmt"
)

func factorial(n int) int {
	if n == 1 {
		return 1
	}

	return n * factorial(n-1)
}

func perfectNumber(a, b int) {
	fmt.Print("Perfect numbers dianta ", a, " dan ", b, ": ")
	for ; a < b; a++ {
		hasil := factorial(a)
		if hasil < b {
			fmt.Print(hasil)
		}
	}
}

func main() {
	var a, b_2311102015 int
	fmt.Print("Masukkan nilai a: ")
	fmt.Scan(&a)
	fmt.Print("Masukkan nilai b: ")
	fmt.Scan(&b_2311102015)
	perfectNumber(a, b_2311102015)
}

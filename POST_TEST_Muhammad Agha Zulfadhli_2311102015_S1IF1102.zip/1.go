package main

import (
	"fmt"
)

func hitungBiayaParkir(jam, menit int, voucher_2311102015 int, isMember bool) int {
	var tarifPerJam float64 = 5000
	var totalBiaya float64
	voucher_2311102015 = voucher_2311102015 % 1000000 / 10000

	if isMember {
		tarifPerJam = 3500
	}

	totalJam := float64(jam)
	if menit >= 30 {
		totalBiaya = tarifPerJam / 2
	}
	if jam == 0 && menit > 0 {
		totalJam = 1
	}

	totalBiaya += totalJam * tarifPerJam
	if (voucher_2311102015 != 0 && voucher_2311102015 > 100) && totalJam > 3 {
		totalBiaya -= totalBiaya * 0.10
	}

	return int(totalBiaya)
}

func main() {
	var jam, menit int
	var voucher_2311102015 int
	var isMember bool

	fmt.Print("Masukkan durasi parkir (jam): ")
	fmt.Scan(&jam)
	fmt.Print("Masukkan durasi parkir (menit): ")
	fmt.Scan(&menit)
	fmt.Print("Apakah member? (true/false): ")
	fmt.Scan(&isMember)
	fmt.Print("Masukkan nomor voucher (jika ada): ")
	fmt.Scan(&voucher_2311102015)
	fmt.Print("Biaya setelah diskon (jika memenuhi syarat): ")
	biaya := hitungBiayaParkir(jam, menit, voucher_2311102015, isMember)
	fmt.Printf("Rp %d\n", biaya)
}

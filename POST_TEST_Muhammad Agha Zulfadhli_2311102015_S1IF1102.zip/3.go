package main

import "fmt"

func agenRahasia(x, y int) int {
	hasil := 0
	for i := 1; i <= 365; i++ {
		if i%x == 0 && i%y != 0 {
			hasil++
		}
	}
	return hasil
}

func main() {
	var x, y_2311102015 int
	fmt.Print("Masukkan nilai x: ")
	fmt.Scan(&x)
	fmt.Print("Masukkan nilai y: ")
	fmt.Scan(&y_2311102015)
	fmt.Print("Jumlah pertemuan dalam setahun: ", agenRahasia(x, y_2311102015))
}

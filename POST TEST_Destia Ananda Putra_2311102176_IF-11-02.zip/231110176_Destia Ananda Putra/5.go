package main

import (
	"fmt"
)

type Partai struct {
	Nama  int
	Suara int
}

func FindPartyIndex(partaiList []Partai, count, partyNumber_2311102176 int) int {
	for i := 0; i < count; i++ {
		if partaiList[i].Nama == partyNumber_2311102176 {
			return i
		}
	}
	return -1
}

func InsertionSort(partaiList []Partai, count int) {
	for i := 1; i < count; i++ {
		key := partaiList[i]
		j := i - 1

		for j >= 0 && (partaiList[j].Suara < key.Suara || (partaiList[j].Suara == key.Suara && partaiList[j].Nama > key.Nama)) {
			partaiList[j+1] = partaiList[j]
			j--
		}
		partaiList[j+1] = key
	}
}

func main() {
	const MaxPartai = 1000000
	var partaiList [MaxPartai]Partai
	var count int

	fmt.Println("Masukkan nomor partai (1 hingga N), akhiri dengan -1:")

	for {
		var partyNumber_2311102176 int
		fmt.Print("Masukkan nomor pada partai: ")
		fmt.Scan(&partyNumber_2311102176)

		if partyNumber_2311102176 == -1 {
			break
		}

		index := FindPartyIndex(partaiList[:], count, partyNumber_2311102176)
		if index == -1 {

			partaiList[count] = Partai{Nama: partyNumber_2311102176, Suara: 1}
			count++
		} else {

			partaiList[index].Suara++
		}
	}

	InsertionSort(partaiList[:], count)

	fmt.Println("Hasil perolehan suara:")
	for i := 0; i < count; i++ {
		fmt.Printf("Partai %d: %d suara\n", partaiList[i].Nama, partaiList[i].Suara)
	}
}

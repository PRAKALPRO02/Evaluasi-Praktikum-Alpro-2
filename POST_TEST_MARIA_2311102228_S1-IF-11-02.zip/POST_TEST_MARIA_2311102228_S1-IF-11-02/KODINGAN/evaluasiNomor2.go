package main


import (

	"fmt"
)

func hitungbiaya228( menu int ) {
	var tarifMenu float64
	if menu == 3 {
		tarifMenu == 10.000
	} else if menu > 3 {
		tarifRombongan == 2500
	} else  menu > 50 {
		tarifMenu == 100000

	}

	totalBiaya := 10000 * n * tarifMenu

	 
}


func main(){

	var n int
	var m, o, s int

	fmt.Println("Masukkan jumlah rombongan : ")
	fmt.Scan(&n)
	fmt.Println("Masukkan jumlah menu : ")
	fmt.Scan(&m)
	fmt.Println("Jumlah orang : ")
	fmt.Scan(&o)
	fmt.Println("Sisa makanan(0 untuk tidak dan 1 untuk iya): ")
	fmt.Scan(&s)

}
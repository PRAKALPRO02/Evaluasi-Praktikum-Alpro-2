package main

import (
	"fmt"
)

func ganjil228(n, i  int) {
	
	if n > i {
		return
	}
	if n % 2 != 0 {
		fmt.Print(n, " ")
		
		

	}
	ganjil228(n+1, i)
	
	
}

func main(){

	var i, j  int

	fmt.Print("Masukkan bilangan 1 : ")
	fmt.Scan(&i)
	fmt.Print("Masukkan bilangan 2 : ")
	fmt.Scan(&j)


	ganjil228(0, i)
 	ganjil228(0, j)






}


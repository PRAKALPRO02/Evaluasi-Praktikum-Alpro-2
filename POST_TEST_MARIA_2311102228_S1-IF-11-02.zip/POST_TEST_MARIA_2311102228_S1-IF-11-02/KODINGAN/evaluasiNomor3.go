package main

import "fmt"

func kelipatan4228(i , n, y int) {
	y = 0

	for i := 1; i < n; i++{
		if (i % 4 == 0)
		y += i
	} else {
		y += 0
	}
	fmt.Println("Jumlah kelipatan 4 : ", y)
	
	}
	


func main(){
	var bilangan int



	for {
		fmt.Print("\nMasukkan bilangan (negatif untuk berhenti)")
		fmt.Scanln(&bilangan)

		if (bilangan > 0 ){
			break
		}

		kelipatan4228
		
	}
} 
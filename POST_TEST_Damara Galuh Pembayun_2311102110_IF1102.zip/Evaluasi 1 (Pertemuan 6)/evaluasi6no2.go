//Damara Galuh Pembayun 2311102110
package main

import (
        "fmt"
)

func main() { //mulai program
        var jumlah_Rombongan_21102110 int

		//buat masukin inputan mau berapa rombongan
        fmt.Print("Masukkan jumlah rombongan: ")
        fmt.Scan(&jumlah_Rombongan_21102110)

		//fungsi buat rombongan
        for i := 1; i <= jumlah_Rombongan_21102110; i++ {
                var jumlah_Menu_21102110, jumlah_Orang_21102110, sisa_Makanan_21102110 int

				//buat masukin inputan jumlah menu, jumlah orang, dan status sisa makanan
                fmt.Printf("Masukkan jumlah menu, jumlah orang, dan status sisa makanan (0 untuk tidak, 1 untuk iya) rombongan %d: ", i)
                fmt.Scan(&jumlah_Menu_21102110, &jumlah_Orang_21102110, &sisa_Makanan_21102110)

                //hitung total biaya
				total_Biaya_21102110 := hitung_TotalBiaya(jumlah_Menu_21102110)
                if sisa_Makanan_21102110 == 1 {
                        total_Biaya_21102110 *= jumlah_Orang_21102110
                }

                fmt.Printf("Total biaya untuk rombongan %d: Rp %d\n", i, total_Biaya_21102110)
        }
}

// untuk menghitung total biaya sesuai jumlah menu
func hitung_TotalBiaya(jumlah_Menu_21102110 int) int {
        var total_Biaya_21102110 int

        switch {
        case jumlah_Menu_21102110 <= 3:
                total_Biaya_21102110 = 10000
        case jumlah_Menu_21102110 <= 50:
                total_Biaya_21102110 = 10000 + (jumlah_Menu_21102110-3) * 2500
        default:
                total_Biaya_21102110 = 100000
        }

        return total_Biaya_21102110
}
//Damara Galuh Pembayun 2311102110
//Damara Galuh Pembayun 2311102110
package main

import (
        "fmt"
)

func main() { //mulai awal 
        var a_21102110, b_21102110 int

        // masukan inputan dari kita //masukan nilai a
        fmt.Print("Masukkan nilai a: ")
        fmt.Scan(&a_21102110)

		// masukan inputan dari kita buat yang inputan b
        fmt.Print("Masukkan nilai b: ") 
        fmt.Scan(&b_21102110)

        // buat fungsi panggilan untuk hitung jumlah bilangan ganjil
        jumlah_Ganjil_21102110 := hitung_BilanganGanjil(a_21102110, b_21102110)

        // fungsi untuk menampilkan hasil
        fmt.Printf("Banyaknya angka ganjil: %d\n", jumlah_Ganjil_21102110)
}

// fungsi untuk hitung jumlah bilangan ganjil dalam jangka a sampai b
func hitung_BilanganGanjil(a, b int) int {
        var jumlah_21102110 int

        // looping(perulangan) dari a sampe b
        for i := a; i <= b; i++ {
                // jika i adalah bilangan ganjil, maka kita dapat tambahkan jumlah
                if i%2 != 0 {
                        jumlah_21102110++
                }
        }

        return jumlah_21102110
}
//Damara Galuh Pembayun 2311102110
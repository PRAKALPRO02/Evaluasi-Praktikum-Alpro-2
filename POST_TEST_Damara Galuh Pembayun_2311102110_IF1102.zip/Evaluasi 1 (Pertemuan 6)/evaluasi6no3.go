//Damara Galuh Pembayun 2311102110
package main

import "fmt"

func main() {
        var bilangan_21102110 int
        var jumlah_Kelipatan_empat_21102110 int

        fmt.Println("Masukkan bilangan (negatif untuk berhenti):")

        // buat baca input bilangan sampe kita masukin  bilangan negatif
        for {
                fmt.Scan(&bilangan_21102110)
                if bilangan_21102110 < 0 {
                        break
                }
                jumlah_Kelipatan_empat_21102110 = hitung_Kelipatan_empat_Rekursif(bilangan_21102110, jumlah_Kelipatan_empat_21102110)
        }

        fmt.Printf("Jumlah bilangan kelipatan 4: %d\n", jumlah_Kelipatan_empat_21102110)
}

// fungsi rekursif untuk hitung jumlah bilangan kelipatan 4 , kayak 4 8 12 .....
func hitung_Kelipatan_empat_Rekursif(bilangan_21102110, jumlah_21102110 int) int {

        // jika bilangan habis dibagi 4, maka bisa tambahkan ke jumlah
        if bilangan_21102110%4 == 0 {
                jumlah_21102110++
        }

        // ini buat manggil rekursif untuk bilangan berikutnya
        if bilangan_21102110 > 0 {
                return hitung_Kelipatan_empat_Rekursif(bilangan_21102110-1, jumlah_21102110)
        }

        // balik lagi buat jumlah total
        return jumlah_21102110
}
//Damara Galuh Pembayun 2311102110
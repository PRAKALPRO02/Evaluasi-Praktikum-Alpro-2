package main

import "fmt"

func digitSama(nomor string) bool {
	for i := 1; i < len(nomor); i++ {
		if nomor[i] != nomor[0] {
			return false
		}
	}
	return true
}

func digitBerbeda(nomor string) bool {
	digitSet := make(map[rune]bool)
	for _, digit := range nomor {
		if digitSet[digit] {
			return false
		}
		digitSet[digit] = true
	}
	return true
}

func main() {
	var jumlahPeserta int
	fmt.Scanln(&jumlahPeserta)

	hadiahA := 0
	hadiahB := 0
	hadiahC := 0

	hasil := make([]string, jumlahPeserta)

	for i := 0; i < jumlahPeserta; i++ {
		var nomorKartu string
		fmt.Scanln(&nomorKartu)

		if digitSama(nomorKartu) {
			hasil[i] = "Hadiah A"
			hadiahA++
		} else if digitBerbeda(nomorKartu) {
			hasil[i] = "Hadiah B"
			hadiahB++
		} else {
			hasil[i] = "Hadiah C"
			hadiahC++
		}
	}

	for _, h := range hasil {
		fmt.Println(h)
	}

	fmt.Printf("Hadiah A: %d\n", hadiahA)
	fmt.Printf("Hadiah B: %d\n", hadiahB)
	fmt.Printf("Hadiah C: %d\n", hadiahC)
}

package main

import "fmt"

func cutAZKA(AZKA int) (int, int) {

	digit := 0
	temp := AZKA
	for temp > 0 {
		digit++
		temp /= 10
	}

	tengah := (digit + 1) / 2

	pangkatKiri := 1
	for i := 0; i < digit-tengah; i++ {
		pangkatKiri *= 10
	}

	AZKAKiri := AZKA / pangkatKiri
	AZKAKanan := AZKA % pangkatKiri

	return AZKAKiri, AZKAKanan
}

func main() {
	var AZKA int
	fmt.Print("Masukkan bilangan bulat positif(>10): ")
	fmt.Scan(&AZKA)

	AZKAKiri, AZKAKanan := cutAZKA(AZKA)

	fmt.Println(AZKAKiri, AZKAKanan)
	fmt.Print("Hasil penjumlahan: ")
	fmt.Println(AZKAKiri + AZKAKanan)
}

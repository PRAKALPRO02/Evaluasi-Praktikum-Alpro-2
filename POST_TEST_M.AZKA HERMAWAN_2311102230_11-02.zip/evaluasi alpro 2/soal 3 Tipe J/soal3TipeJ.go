package main

import "fmt"

func Rekursif(AZ, KA, akumulasi int) int {
	if KA == 0 {
		return akumulasi
	}
	return Rekursif(AZ, KA-1, akumulasi+AZ)
}

func main() {
	var AZ, KA int
	fmt.Print("Masukkan bilangan pertama (AZ): ")
	fmt.Scan(&AZ)
	fmt.Print("Masukkan bilangan kedua (KA): ")
	fmt.Scan(&KA)

	hasil := Rekursif(AZ, KA, 0)
	fmt.Printf("Hasil perkalian %d x %d = %d\n", AZ, KA, hasil)
}

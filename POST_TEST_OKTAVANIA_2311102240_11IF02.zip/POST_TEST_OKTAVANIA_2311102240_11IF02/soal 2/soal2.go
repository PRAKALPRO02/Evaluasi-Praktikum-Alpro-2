package main

import (
	"fmt"
)

func hitungBiaya_2311102240(menu, orang int, sisa bool) int {
	total := 10000

	if menu > 3 {
		total += (menu - 3) * 2500
	}

	if menu > 50 {
		total = 100000
	}
	if sisa {
		total *= orang
	}

	return total
}

func main() {
	var M int
	fmt.Print("Masukkan jumlah rombongan: ")
	fmt.Scan(&M)

	for i := 1; i <= M; i++ {
		var menu, orang, sisaInt int
		fmt.Printf("Masukkan jumlah menu, jumlah orang, dan status sisa makanan (0 untuk tidak, 1 untuk iya) : ")
		fmt.Scan(&menu, &orang, &sisaInt)

		sisa := sisa Int == 1

		total := hitungBiaya_2311102240(menu, orang, sisa)
		fmt.Printf("Total biaya untuk rombongan %d: Rp %d\n", i, total)
	}
	}

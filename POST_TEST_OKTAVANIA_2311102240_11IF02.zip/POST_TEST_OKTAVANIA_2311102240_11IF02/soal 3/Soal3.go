package main

import (
	"fmt"
)

func jumlahKelipatan4() int {
	var bilangan_2311102240 int
	fmt.Scan(&bilangan_2311102240)

	if bilangan_2311102240 < 0 {
		return 0
	}

	if bilangan_2311102240%4 == 0 {
		return bilangan_2311102240 + jumlahKelipatan4()
	}
	return jumlahKelipatan4()
}

func main() {
	fmt.Println("Masukkan bilangan (negatif untuk berhenti): ")

	hasil := jumlahKelipatan4()
	fmt.Println("Jumlah bilangan kelipatan 4: ", hasil)
}

package main

import (
	"fmt"
)

// Fungsi untuk memeriksa apakah suatu bilangan adalah perfect number
func isPerfectNumber225(x int) bool {
	sum := 0
	// Menjumlahkan faktor-faktor dari x (tidak termasuk x itu sendiri)
	for i := 1; i < x; i++ {
		if x%i == 0 {
			sum += i
		}
	}
	// Memeriksa apakah jumlah faktor sama dengan x
	return sum == x
}

// Fungsi untuk menampilkan barisan perfect number dalam rentang a hingga b
func tampilkanPerfectNumbers225(a, b int) {
	fmt.Printf("Perfect numbers antara %d dan %d: ", a, b)
	found := false
	for i := a; i <= b; i++ {
		if isPerfectNumber225(i) {
			fmt.Printf("%d ", i)
			found = true
		}
	}
	if !found {
		fmt.Println("Tidak ada perfect number dalam rentang ini.")
	} else {
		fmt.Println() // Ganti baris setelah menampilkan bilangan
	}
}

func main() {
	var a, b int

	// Input dari pengguna
	fmt.Print("Masukkan nilai a: ")
	fmt.Scan(&a)

	fmt.Print("Masukkan nilai b: ")
	fmt.Scan(&b)

	// Tampilkan bilangan perfect number antara a dan b
	tampilkanPerfectNumbers225(a, b)
}

package main

import (
	"fmt"
)

func hitungPertemuan225(x, y int) int {
	jumlahPertemuan := 0

	// Iterasi melalui hari-hari dalam setahun (1 hingga 365)
	for hari := 1; hari <= 365; hari++ {
		// Memeriksa apakah hari adalah kelipatan dari x tapi bukan kelipatan dari y
		if hari%x == 0 && hari%y != 0 {
			jumlahPertemuan++
		}
	}

	return jumlahPertemuan
}

func main() {
	var x, y int

	// Input dari pengguna
	fmt.Print("Masukkan nilai x: ")
	fmt.Scan(&x)

	fmt.Print("Masukkan nilai y: ")
	fmt.Scan(&y)

	// Hitung jumlah pertemuan
	jumlahPertemuan := hitungPertemuan225(x, y)

	// Tampilkan hasil
	fmt.Printf("Jumlah pertemuan dalam setahun: %d\n", jumlahPertemuan)
}

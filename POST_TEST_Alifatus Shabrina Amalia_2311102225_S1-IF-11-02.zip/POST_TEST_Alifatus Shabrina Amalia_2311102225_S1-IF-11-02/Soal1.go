package main

import (
	"fmt"
)

// Fungsi untuk menghitung biaya sewa
func hitungBiayaSewa225(durasiJam, durasiMenit int, isMember bool, nomorVoucher string) float64 {
	// Menghitung durasi total dalam jam
	if durasiMenit >= 10 {
		durasiJam += 1
	}

	// Tarif per jam
	tarifPerJam := 5000.0
	if isMember {
		tarifPerJam = 3500.0
	}

	// Biaya total berdasarkan durasi
	biayaTotal := tarifPerJam * float64(durasiJam)

	// Cek apakah durasi lebih dari 3 jam dan nomor voucher 5 atau 6 digit
	if durasiJam > 3 && (len(nomorVoucher) == 5 || len(nomorVoucher) == 6) {
		biayaTotal *= 0.9 // Diskon 10%
	}

	return biayaTotal
}

func main() {
	var durasiJam, durasiMenit int
	var isMember bool
	var nomorVoucher string

	// Input dari pengguna
	fmt.Print("Masukkan durasi (jam): ")
	fmt.Scan(&durasiJam)

	fmt.Print("Masukkan durasi (menit): ")
	fmt.Scan(&durasiMenit)

	fmt.Print("Apakah member? (true/false): ")
	fmt.Scan(&isMember)

	fmt.Print("Masukkan nomor voucher (jika ada): ")
	fmt.Scan(&nomorVoucher)

	// Hitung biaya sewa
	biaya := hitungBiayaSewa225(durasiJam, durasiMenit, isMember, nomorVoucher)

	// Tampilkan hasil
	fmt.Printf("Biaya sewa setelah diskon (jika memenuhi syarat): Rp %.2f\n", biaya)
}

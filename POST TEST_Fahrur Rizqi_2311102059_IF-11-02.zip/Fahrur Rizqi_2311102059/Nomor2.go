package main

import "fmt"

func isPerfectNumber_2311102059(num int) bool {
	sum := 1
	for i := 2; i*i <= num; i++ {
		if num%i == 0 {
			sum += i
			if i*i != num {
				sum += num / i
			}
		}
	}
	return sum == num
}

func findPerfectNumbers(a, b int) {
	fmt.Print("Perfect numbers antara ", a, " dan ", b, ": ")
	for i := a; i <= b; i++ {
		if isPerfectNumber_2311102059(i) {
			fmt.Print(i, " ")
		}
	}
	fmt.Println()
}

func main() {
	var a, b int
	fmt.Print("Masukan nilai a: ")
	fmt.Scan(&a)
	fmt.Print("Masukan nilai b: ")
	fmt.Scan(&b)
	findPerfectNumbers(a, b)
}

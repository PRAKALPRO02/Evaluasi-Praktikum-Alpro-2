package main

import (
	"fmt"
)

func hitungBiayaSewa_2311102059(jam, menit int, isMember bool, voucher string) float64 {
	tarifPerJam := 3500.0
	if !isMember {
		tarifPerJam = 5000.0
	}

	durasiJam := float64(jam)
	if menit >= 10 && jam > 0 {
		durasiJam += 1
	}

	biayaDasar := durasiJam * tarifPerJam
	diskon := 0.0
	if len(voucher) == 5 || len(voucher) == 6 {
		diskon = 0.1
	}

	biayaAkhir := biayaDasar * (1 - diskon)
	return biayaAkhir
}

func main() {
	var jam, menit int
	var isMember bool
	var voucher string

	fmt.Print("Masukan durasi(jam): ")
	fmt.Scan(&jam)
	fmt.Print("Masukan durasi(menit): ")
	fmt.Scan(&menit)
	fmt.Print("Apakah member(true/false): ")
	fmt.Scan(&isMember)
	fmt.Print("Masukan nomor voucher(jika ada): ")
	fmt.Scan(&voucher)

	biaya := hitungBiayaSewa_2311102059(jam, menit, isMember, voucher)
	fmt.Printf("Biaya sewa setelah diskon (jika memenuhi syarat): Rp. %.2f\n", biaya)
}

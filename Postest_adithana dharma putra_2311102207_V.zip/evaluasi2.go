package main
import "fmt"

func cekPerfect207(angka207 int) bool {
    jumlah207 := 1
    for i207 := 2; i207*i207 <= angka207; i207++ {
        if angka207%i207 == 0 {
            jumlah207 += i207
            if i207*i207 != angka207 {
                jumlah207 += angka207 / i207
                }
            }
        }
    return jumlah207 == angka207
}

func mencari(a207, b207 int) {
    fmt.Print("Perfect numbers antara ", a207, " dan ", b207, ": ")
    for i207 := a207; i207 <= b207; i207++ {
            if cekPerfect207(i207) {
            	fmt.Printf("%d ",i207)
            }
    }
    fmt.Println()
}

func main() {
        var a207 int
		var b207 int
        fmt.Print("Masukkan nilai a: ")
        fmt.Scan(&a207)
        fmt.Print("Masukkan nilai b: ")
        fmt.Scan(&b207)

        mencari(a207, b207)
}
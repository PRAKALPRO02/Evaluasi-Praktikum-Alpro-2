package main

import (
	"fmt"
)

func main() {
	var jumlahRombongan int
	fmt.Print("Masukkan jumlah rombongan: ")
	fmt.Scan(&jumlahRombongan)

	for i := 1; i <= jumlahRombongan; i++ {
		var jumlahMenu, jumlahOrang, statusSisa int
		fmt.Printf("Masukkan jumlah menu, jumlah orang, dan status sisa makanan (0 untuk tidak, 1 untuk iya) untuk rombongan %d: ", i)
		fmt.Scan(&jumlahMenu, &jumlahOrang, &statusSisa)

		biaya := jumlahMenu * jumlahOrang * 1000

		if statusSisa == 1 {
			biaya += 50000
		}

		fmt.Printf("Total biaya untuk rombongan %d: Rp %d\n", i, biaya)
	}
}

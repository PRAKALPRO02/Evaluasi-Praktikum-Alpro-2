package main

import (
	"fmt"
)

func main() {
	var a, b int
	fmt.Print("Masukkan nilai a: ")
	fmt.Scan(&a)
	fmt.Print("Masukkan nilai b: ")
	fmt.Scan(&b)

	if a > b {
		a, b = b, a
	}

	printOdd := 0
	for i := a; i <= b; i++ {
		if i%2 != 0 {
			printOdd++
		}
	}

	fmt.Printf("Banyaknya angka ganjil: %d\n", printOdd)
}

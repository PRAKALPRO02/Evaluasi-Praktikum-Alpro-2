package main

import (
	"fmt"
)

func countOddNumbers(a_2311102094, b int) int {
	count := 0
	for i := a_2311102094; i <= b; i++ {
		if i%2 != 0 {
			count++
		}
	}
	return count
}

func main() {
	// Input dari pengguna
	var a_2311102094, b int
	fmt.Print("Masukkan bilangan a : ")
	fmt.Scanln(&a_2311102094)
	fmt.Print("masukkan bilangan b : ")
	fmt.Scanln(&b)

	count := countOddNumbers(a_2311102094, b)
	fmt.Printf("Banyaknya angka ganjil ialah: %d\n", count)

}

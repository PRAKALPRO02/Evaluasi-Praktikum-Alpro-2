package main

import "fmt"

func main() {
	fmt.Println("Masukkan bilangan negatif:")
	var sum_2311102094 int
	var input_2311102094 int
	for {
		fmt.Scanln(&input_2311102094)
		if input_2311102094 < 0 {
			break
		}
		sum_2311102094 += countMultiplesOfFour(input_2311102094)
	}
	fmt.Printf("Jumlah bilangan kelipatan 4: %d\n", sum_2311102094)
}

func countMultiplesOfFour(n_2311102094 int) int {
	if n_2311102094%4 == 0 {
		return 1
	}
	return 0
}

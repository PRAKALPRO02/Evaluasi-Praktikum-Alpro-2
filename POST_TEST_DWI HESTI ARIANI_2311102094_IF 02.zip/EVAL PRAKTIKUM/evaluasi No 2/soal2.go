package main

import "fmt"

func main() {
    var rombongan_2311102094 int
    fmt.Print(" Masukkan jumlah rombongan: ")
    fmt.Scanln(&rombongan_231102094)
	var jumlahMenu,jumlahOrang int
	fmt.Print(" Masukkan jumlah menu dan jumlah orang: ")
    fmt.Scanln(&jumlahMenu, &jumlahOrang)
	var sisaMakanan bool{
		if sisaMakanan = 0
	}

    

    if sisaBeratGram >= 500 {
        biayaSisaGram := sisaBeratGram * 5
        biayaTotal := biayaTotalKg + biayaSisaGram
        fmt.Println("Biaya total:", biayaTotal)
    } else if sisaBeratGram < 500 {
        if totalBeratKg > 10 {
            biayaTotal := biayaTotalKg
            fmt.Println("Biaya total:", biayaTotal)
        } else {
            biayaSisaGram := sisaBeratGram * 15
            biayaTotal := biayaTotalKg + biayaSisaGram
            fmt.Println("Biaya total:", biayaTotal)
        }
    }
}

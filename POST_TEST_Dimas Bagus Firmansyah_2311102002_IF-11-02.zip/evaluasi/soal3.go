package main

import (
    "fmt"
)

func bilanganNegatif_2311102002(sum int) int {
    var num int
    fmt.Scan(&num) 
    if num < 0 {
        return sum
    }

    if num > 0 && num%4 == 0 {
        sum += num
    }
    return bilanganNegatif_2311102002(sum)
}

func main() {
    fmt.Println("Masukkan bilangan (negatif untuk berhenti):")
    result := bilanganNegatif_2311102002(0) 
    fmt.Println("Jumlah bilangan kelipatan 4:", result)
}
package main

import (
    "fmt"
)

func hitungTotalBiaya_2311102002(jumlahMenu, jumlahOrang int, sisa bool) int {
    biaya := 10000

    if jumlahMenu > 3 {
        biaya += (jumlahMenu - 3) * 2500
    }

    if jumlahMenu > 50 {
        biaya = 100000
    }

    if sisa {
        biaya *= jumlahOrang
    }

    return biaya
}

func main() {
    var M int
    fmt.Print("Masukkan jumlah rombongan: ")
    fmt.Scan(&M)

    for i := 1; i <= M; i++ {
        var jumlahMenu, jumlahOrang, sisaInput int
        var sisa bool

        fmt.Printf("Masukkan jumlah menu, jumlah orang, dan sisa makanan (0 untuk tidak, 1 untuk iya) untuk rombongan %d: ", i)
        fmt.Scan(&jumlahMenu, &jumlahOrang, &sisaInput)

        sisa = sisaInput == 1

        hitungTotalBiaya_2311102002 := hitungTotalBiaya_2311102002(jumlahMenu, jumlahOrang, sisa)

        fmt.Printf("Total biaya untuk rombongan %d: Rp %d\n", i, hitungTotalBiaya_2311102002)
    }
}
// IKRAM IRIANSYAH
// 2311102184
// IF-11-02

package main

import (
	"fmt"
	"strconv"
)

func main() {
	// Input bilangan bulat positif (>10)
	var input int
	fmt.Print("2311102184_Masukkan bilangan bulat positif (>10): ")
	fmt.Scanln(&input)

	// Konversi bilangan menjadi string untuk memotong
	numStr := strconv.Itoa(input)
	length := len(numStr)

	var num1, num2 int

	if length%2 != 0 {
		num1, _ = strconv.Atoi(numStr[:length/2+1])
		num2, _ = strconv.Atoi(numStr[length/2+1:])
	} else {
		num1, _ = strconv.Atoi(numStr[:length/2])
		num2, _ = strconv.Atoi(numStr[length/2:])
	}

	fmt.Println("2311102184_Bilangan 1:", num1)
	fmt.Println("2311102184_Bilangan 2:", num2)

	fmt.Println("2311102184_Hasil penjumlahan:", num1+num2)
}
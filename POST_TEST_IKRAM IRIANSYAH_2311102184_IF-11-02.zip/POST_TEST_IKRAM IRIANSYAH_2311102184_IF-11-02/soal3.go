// IKRAM IRIANSYAH
// 2311102184
// IF-11-02

package main

import (
	"fmt"
)

func multiply(n, m int) int {

	if m == 0 {
		return 0
	}

	return n + multiply(n, m-1)
}

func main() {
	var n, m int

	fmt.Print("2311102184_Masukkan nilai n: ")
	fmt.Scan(&n)
	fmt.Print("2311102184_Masukkan nilai m: ")
	fmt.Scan(&m)

	result := multiply(n, m)

	fmt.Printf("2311102184_Hasil dari %d x %d = %d\n", n, m, result)
}
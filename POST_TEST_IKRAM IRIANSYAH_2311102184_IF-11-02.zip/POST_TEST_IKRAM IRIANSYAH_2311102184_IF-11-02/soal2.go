// IKRAM IRIANSYAH
// 2311102184
// IF-11-02

package main

import (
	"fmt"
	"strconv"
)

func bil1_2311102184(n int) bool {
	strN := strconv.Itoa(n)
	for i := 1; i < len(strN); i++ {
		if strN[i] != strN[0] {
			return false
		}
	}
	return true
}

func bil2(n int) bool {
	strN := strconv.Itoa(n)
	digitMap := make(map[rune]bool)

	for _, digit := range strN {
		if digitMap[digit] {
			return false
		}
		digitMap[digit] = true
	}
	return true
}

func main() {
	var N int
	fmt.Print("Masukkan jumlah peserta: ")
	fmt.Scan(&N)

	jumlahA, jumlahB, jumlahC := 0, 0, 0

	for i := 1; i <= N; i++ {
		var nomorKartu int
		fmt.Printf("Masukkan nomor kartu peserta ke-%d: ", i)
		fmt.Scan(&nomorKartu)

		if bil1_2311102184(nomorKartu) {
			fmt.Println("Hadiah A")
			jumlahA++
		} else if bil2(nomorKartu) {
			fmt.Println("Hadiah B")
			jumlahB++
		} else {
			fmt.Println("Hadiah C")
			jumlahC++
		}
	}

	fmt.Printf("\nJumlah yang memperoleh Hadiah A: %d\n", jumlahA)
	fmt.Printf("Jumlah yang memperoleh Hadiah B: %d\n", jumlahB)
	fmt.Printf("Jumlah yang memperoleh Hadiah C: %d\n", jumlahC)
}
package main 

import (
	"fmt"
)

func perkalian_2311102029(n int, m int) {
	var n int
	fmt.Scan(&n)
	fmt.Println(perkalian(n))

	var m int
	fmt.Scan(&n)
	fmt.Println(perkalian(n))
}

func perkalian (n int ) int {
	if n == 1 {
			return 1
	}else{
			return n * perkalian(n-1)
	}
}

func main(){

	var n int 
	fmt.Printf("Masukan Bilangan n: ")
	fmt.Scan(n)

	var m int
	fmt.Printf("Masukan Bilangan m: ")
	fmt.Scan(m)

	fmt.Printf("Hasil dari n x m = ")
	fmt.Scan(n * m)

}
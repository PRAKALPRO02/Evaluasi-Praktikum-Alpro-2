package main 

import ( 
	"fmt"
)

func hitungPotongan_2311102029 (n int) {
	for n 
}

package main

import (
	"fmt"
)
func isGakdapatHadiah(digit int) bool {
	if semuaDigitGenap && semuaDigitGenap {
		return true
	}
	return false
}

func semuaDigitSama_2311102029(nomor int) bool {
	digitPertama := nomor % 10
	nomor /= 10
	for nomor > 0 {
		digit := nomor % 10 
		if digit != digitPertama {
			return false
		}
		nomor /= 10
		}
	return true
}

func semuaDigitGenap(nomor int) bool {
	for nomor > 0 {
		digit := nomor % 10
		if digit%2 != 0 {
			return false
		}
		nomor /= 10
	}
	return true
}

func tentukanHadiah(nomor int) string {
	digitPertama := nomor % 10
	if semuaDigitSama_2311102029(nomor) && (digitPertama) {
		return "Hadiah A"
	}
	if semuaDigitGenap(nomor){
		return "Hadiah B	"
	}
}
{
func main() {
	var n int
	fmt.Print("Masukan Jumlah Peserta: ")
	fmt.Scan(&n)

	jumlahhadiahA := 0
	jumlahhadiahB := 0
	jumlahhadiahC := 0

	for i := 0; i < n; i++ {
		var nomor int
		fmt.Printf ("Masukan Nomor Kartu ke-%d: ", i+1)
		fmt.Scan(&nomor)

		jenisHadiah := tentukanHadiah(nomor)
		fmt.Println(jenisHadiah)

		switch jenisHadiah {
		case "Hadiah A":
			jumlahhadiahA++
		case "Hadiah B":
			jumlahhadiahB++
		case "Hadiah C":
			jumlahhadiahC++
		}
	}
}
	fmt.Printf("Jumlah: HadiahA = %d, HadiahB = %d, HadiahC = %d\n",jumlahhadiahA,jumlahhadiahB,jumlahhadiahC)
}
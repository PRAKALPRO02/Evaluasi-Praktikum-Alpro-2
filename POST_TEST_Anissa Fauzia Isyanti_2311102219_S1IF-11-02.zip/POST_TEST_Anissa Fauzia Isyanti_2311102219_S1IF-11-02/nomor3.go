package main
import "fmt"


func ketemu(x, y, tahun int){
	if tahun %x = 0 && tahun %y !=0 {
		ketemu = true
		tahun++
	}
}
func main(){
	var x int
	var y int
	fmt.Println("X:")
	fmt.Scan(&x)
	fmt.Println("Y:")
	fmt.Scan(&y)
	fmt.Println("Julah pertemuan dalam setahun: ")
	fmt.Scan(&tahun)
	
}


package main

import (
	"fmt"
)

// Fungsi untuk menghitung Biaya sewa
func hitungBiayaSewa(jam, menit int, noVoucher int, isMember bool) int {
	// Tentukan tarif per jam berdasarkan statur emember
	var tarifPerJam float64
	if isMember == true {
		tarifPerJam = 3500
	} else {
		tarifPerJam = 5000
	}

	// Konversi durasi parkir ke jam (perhatikan aturan 30 menit)
	totalJam := float64(jam)
	if menit <= 10 {
		totalJam += 1
	} else if jam == 0 && menit > 10 {
		// Jika durasi kurang dari 1 jam, hitung sebagai 1 jam
		totalJam = 1
	}

	// Hitung biaya sebelum diskon
	totalBiaya := totalJam * tarifPerJam

	// Diskon tambahan 15% jika member
	if noVoucher > 1000 && noVoucher < 1000000 {
		totalBiaya *= 0.1
	}

	// Bulatkan ke bawah ke bilangan bulat
	return int(totalBiaya)
}

func main() {
	// Input dari pengguna
	var jam, menit int
	var isMember bool
	var noVoucher int

	fmt.Print("Masukkan durasi parkir (jam): ")
	fmt.Scan(&jam)
	fmt.Print("Masukkan durasi parkir (menit): ")
	fmt.Scan(&menit)
	fmt.Print("Apakah Anda member? (true/false): ")
	fmt.Scan(&isMember)
	fmt.Print("Masukkan nomor voucher (jikaada): ")
	fmt.Scan(&noVoucher)

	// Hitung Biaya sewa
	biaya := hitungBiayaSewa(jam, menit, noVoucher, isMember)

	// Output Biaya sewa
	fmt.Printf("Biaya sewa: Rp %d\n", biaya)
}

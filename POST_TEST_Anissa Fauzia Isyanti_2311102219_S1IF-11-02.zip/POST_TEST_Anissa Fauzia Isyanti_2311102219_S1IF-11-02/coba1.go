package main

import (
	"fmt"
)

// Fungsi untuk menghitung biaya parkir
func hitungbiayasewa(jam, menit int, noVoucher int, isMember bool) int {
	// Tentukan tarif per jam berdasarkan jenis kendaraan
	var tarifPerJam float64
	if isMember == true {
		tarifPerJam = 3500
	} else {
		tarifPerJam = 5000
	}

	// Konversi durasi parkir ke jam (perhatikan aturan 30 menit)
	totalJam := float64(jam)
	if jam == 0 && menit > 10 {
		// Jika durasi kurang dari 1 jam, hitung sebagai 1 jam
		totalJam = 1
	}

	// Hitung biaya sebelum diskon
	totalBiaya := totalJam * tarifPerJam

	// Diskon 10% jika lebih dari 5 jam parkir
	if noVoucher > 10000 && noVoucher > 100000 {
		totalBiaya *= 0.1
	}
	// Bulatkan ke bawah ke bilangan bulat
	return int(totalBiaya)
}

func main() {
	// Input dari pengguna
	var jam, menit int
	var isMember bool
	var noVoucher int

	fmt.Print("Masukkan durasi parkir (jam): ")
	fmt.Scan(&jam)
	fmt.Print("Masukkan durasi parkir (menit): ")
	fmt.Scan(&menit)
	fmt.Print("Apakah Anda member? (true/false): ")
	fmt.Scan(&isMember)
	fmt.Print("Masukkan nomor voucher (jika ada): ")
	fmt.Scan(&noVoucher)

	// Hitung biaya parkir
	biaya := hitungbiayasewa(jam, menit, noVoucher, isMember)

	// Output biaya parkir
	fmt.Printf("Biaya sewa setelah diskon (ika memenuhi syarat): Rp %d\n", biaya)
}

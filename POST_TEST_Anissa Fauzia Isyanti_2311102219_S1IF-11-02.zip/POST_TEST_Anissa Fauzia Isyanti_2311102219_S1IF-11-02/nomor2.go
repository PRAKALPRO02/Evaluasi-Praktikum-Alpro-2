package main

import (
	"fmt"
)

func faktor_219(a, i int) {
	if i > a {
		return
	}
	if a%i == 0 {
		fmt.Print(i, " ")
	}
	faktor_219(a, i+1)
}

func perfect (i, a, b int, faktor_219 int){
	if faktor_219[1] + faktor_219[i]
	i ++
}

func perfect(a,b int){
	if faktor_219
}

func main() {
	var a int
	var b int
	fmt.Print("Masukkan nilai a: ")
	fmt.Scan(&a)
	fmt.Print("Masukkan nilai b: ")
	fmt.Scan(&b)
	fmt.Println("Perfect numbers antara ", a, "dan ", b, ": ", perfect)

	perfect(i, 1)
	fmt.Println()
}

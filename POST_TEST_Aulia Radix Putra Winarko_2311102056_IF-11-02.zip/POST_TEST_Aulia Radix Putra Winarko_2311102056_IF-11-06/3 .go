package main

import "fmt"

func jumalahMinpat(n_2311102056 int) int {
	fmt.Print("Masukkan bilangan (negatif untuk berhenti): ")
	fmt.Scan(&n_2311102056)
	if n_2311102056 == -1 {
		return 0
	} else if n_2311102056%4 == 0 {
		return n_2311102056 + jumalahMinpat(n_2311102056)
	} else {
		return jumalahMinpat(n_2311102056)
	}
}

func main() {
	var angka, hasil int
	hasil = jumalahMinpat(angka)
	fmt.Println("Jumlah bilangan kelipatan 4: ", hasil)
}

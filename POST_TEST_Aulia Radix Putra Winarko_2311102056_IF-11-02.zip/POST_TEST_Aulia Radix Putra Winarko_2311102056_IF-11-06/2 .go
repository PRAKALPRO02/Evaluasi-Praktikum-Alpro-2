package main

import "fmt"


func main()  {
	var rombongan int
	var jumlahMenu_2311102056,orang int
	var sisa int
	const hargaBiasa = 10000
	const hargaPerMenu = 2500
	const hargaMaks = 50000
	
	fmt.Print("Masukan Jumlah Rombongan : ")
	fmt.Scan(&rombongan)

	for i:= 1; i<= rombongan; i++ {
		fmt.Println("Masukan jumlah menu, jumlah orang, dan status sisa makanan (0 untuk tidak, 1 untuk iya): ")
		fmt.Scan(&jumlahMenu_2311102056, &orang, &sisa)
		totalHarga:= hargaBiasa

		if jumlahMenu_2311102056 > 3 {
			totalHarga += (jumlahMenu_2311102056 - 3) * hargaPerMenu
		}

		totalHarga *= orang
		if sisa == 1 {
			totalHarga += orang * totalHarga
		}

		fmt.Println("Total Biaya untuk ", rombongan, ": Rp", totalHarga)
	}
}

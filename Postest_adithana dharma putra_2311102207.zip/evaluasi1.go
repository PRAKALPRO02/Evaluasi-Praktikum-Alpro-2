package main
import "fmt"

func hitungBiayaSewa(jam207, menit207 int, apakahmemeber207 bool) float64 {
    var tarifperjam207 float64
    if  apakahmemeber207 {
        tarifperjam207 = 3500
    } else{
		tarifperjam207 = 5000 
    }

    totaljam207 := float64(jam207)
	if jam207 == 0 && menit207 >= 10 {
        totaljam207 = 1
    }
	
    totalBiaya207 := totaljam207 * tarifperjam207
    if totaljam207 > 3 {
        totalBiaya207 *= 0.9
    }

    return totalBiaya207
}

func main() {
    var jam207, menit207 int
	var apakahmemeber207 bool
	var voucer207 string

    fmt.Print("Masukkan durasi peminjaman (jam): ")
    fmt.Scan(&jam207)
    fmt.Print("Masukkan durasi peminjaman (menit): ")
    fmt.Scan(&menit207)
    fmt.Print("Masukkan voucer: ")
    fmt.Scan(&voucer207)
    fmt.Print("Apakah Anda member? (true/false): ")
    fmt.Scan(&apakahmemeber207)

    biaya207 := hitungBiayaSewa(jam207, menit207, apakahmemeber207)
    fmt.Printf("Biaya parkir setelah diskon(jika dapat): Rp.%.2f\n", biaya207)
}

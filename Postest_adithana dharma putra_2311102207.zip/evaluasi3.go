package main
import "fmt"

func main() {
	const totalhari207 = 365
	var x207 int
	var y207 int

	fmt.Print("Masukkan nilai X: ")
	fmt.Scan(&x207)
	fmt.Print("Masukkan nilai Y: ")
	fmt.Scan(&y207)

	jumlahketemu207 := 0
	for day207 := 1; day207 <= totalhari207; day207++ {
		if day207%x207 == 0 && day207%y207 != 0 {
			jumlahketemu207++
		}
	}

	fmt.Printf("Jumlah pertemuan selama setahun adalah: %d\n", jumlahketemu207)
}
package main

import "fmt"

func jumlahKelipatan4() int {
  var n_2311102032 int
  fmt.Scan(&n_2311102032)
	if n_2311102032 < 0 {
		return 0
	}

	if n_2311102032%4 == 0 {
		return n_2311102032 + jumlahKelipatan4()
	}
	return jumlahKelipatan4()
}

func main() {
	fmt.Println("Masukkan bilangan(negatif untuk berhenti):")
  fmt.Print("Jumlah bilangan kelipatan 4: ", jumlahKelipatan4())
}

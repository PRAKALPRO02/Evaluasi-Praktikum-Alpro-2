package main

import "fmt"

func hitungGanjil(a, b int) int {
	count_2311102032 := 0
	for i := a; i < b; i++ {
    if i % 2 != 0 {
      count_2311102032++
    }
	}
  return count_2311102032
}

func main() {
	var a, b int
	fmt.Print("Masukkan nilai a: ")
  fmt.Scan(&a)
  fmt.Print("Masukkan nilai b: ")
  fmt.Scan(&b)
  fmt.Print("Banyaknya angka ganjil:")
  fmt.Print(hitungGanjil(a,b))
}
package main

import "fmt"

func hitungTotalBiaya(jumlahMenu, banyakOrang int, sisa bool) int {
	var totalBiaya int
	if jumlahMenu <= 3 {
		totalBiaya = 10000
	} else if jumlahMenu > 50 {
		totalBiaya = 100000
	} else {
		totalBiaya = 10000 + (jumlahMenu-3)*2500
	}

	if sisa {
		totalBiaya *= banyakOrang
	}
	return totalBiaya
}

func main() {
	var M, banyakOrang, jumlahMenu int
	var statusSisa_2311102032 bool

	fmt.Print("Masukkan jumlah rombongan: ")
	fmt.Scan(&M)

	for i := 1; i <= M; i++ {
		fmt.Print("Masukkan jumlah menu, jumlah orang, dan status sisa makanan (0 untuk tidak, 1 untuk iya): ")
		fmt.Scan(&jumlahMenu, &banyakOrang, &statusSisa_2311102032)

		totalBiaya := hitungTotalBiaya(jumlahMenu, banyakOrang, statusSisa_2311102032)
		fmt.Printf("Total biaya untuk rombongan %d: Rp %d\n", i, totalBiaya)
	}
}
